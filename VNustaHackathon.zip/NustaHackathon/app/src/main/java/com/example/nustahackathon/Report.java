package com.example.nustahackathon;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Report extends AppCompatActivity {
    String httpurl="http://192.168.1.5/Hackathon/report.php";
    TextView edReference1,edrepossessiondate,edrcno,edrcstatus, edBank, edContractno, edRequestfrom, edAssetMake, edAssetModel, edYearofmfg, edHMRKMR, edChassisNumber, edEngineNumber, edInspector, edLocation, edRCFitnessValid, edTaxStatus, edbuyer, edwarenty_coast, edtransportayion_coast, edrto_expences, edinsurance_cost, edtaxes_penalty, edrefurb_coast, edparking_charges, edtotal_coast;

    TextView edpurpose1;
    String sReference1,srepossessiondate,spurpose1,srcno,srcstatus, sBank, sContractno, sRequestfrom, sAssetMake, sAssetModel, sYearofmfg, sHMRKMR, sChassisNumber,sEngineNumber, sInspector, sLocation, sRCFitnessValid, sTaxStatus;
    private Button btn;
    private LinearLayout llPdf;
    TextView parSilencer,parAbnormalEngineNoise,parPlugs,parOil,parRadiotorCondensor,parOilLeakage,parFanBelts,parFilters;
    TextView conSilencer,conEngineNoise,conPlugs,conOil,conRadiotorCondensor,conOilleakage,confanbelts,conFilters;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        parSilencer =findViewById(R.id.parsilen);
                parAbnormalEngineNoise=findViewById(R.id.parabnormalenginenoise);
        parPlugs=findViewById(R.id.parplugs);
                parOil=findViewById(R.id.paroil);
        parRadiotorCondensor=findViewById(R.id.parRadiatorCondensor);
                parOilLeakage=findViewById(R.id.parOilLeakage);
        parFanBelts=findViewById(R.id.parFanbelts);
                parFilters=findViewById(R.id.parFilter);


        conSilencer=findViewById(R.id.consilencer);
                conEngineNoise=findViewById(R.id.conabnormalenginenoise);

        conPlugs=findViewById(R.id.conplugs);
                conOil=findViewById(R.id.conOil);
        conRadiotorCondensor=findViewById(R.id.conRadiotorCondenser);
                conOilleakage=findViewById(R.id.conOilleakage);
        confanbelts=findViewById(R.id.conFanbelts);
                conFilters=findViewById(R.id.conFilter);




        edReference1=findViewById(R.id.edref);
        edYearofmfg=findViewById(R.id.edYearofmfg);
        edpurpose1=(TextView) findViewById(R.id.edpurp);
        edrepossessiondate=findViewById(R.id.edrepdate);
        edrcno=findViewById(R.id.edrcnumber);
        edrcstatus=findViewById(R.id.edrcstatus);
        edBank=findViewById(R.id.edBank);
        edContractno=findViewById(R.id.edContractno);
        edRequestfrom=findViewById(R.id.edRequestfrom);
        edAssetMake=findViewById(R.id.edAssetMake);
        edAssetModel=findViewById(R.id.edAssetModel);
        edYearofmfg=findViewById(R.id.edYearofmfg);
        edHMRKMR=findViewById(R.id.edHMRKMR);
        edChassisNumber=findViewById(R.id.edChassisNumber);
        edEngineNumber=findViewById(R.id.edEngineNumber);
        edInspector=findViewById(R.id.edinspector);
        edLocation=findViewById(R.id.edloc);
        edRCFitnessValid=findViewById(R.id.edrcfitnessvalid);
        edTaxStatus=findViewById(R.id.edtaxStatus);
        edbuyer=findViewById(R.id.edbuyer);
        edwarenty_coast=findViewById(R.id.edwarenty_coast);
        edtransportayion_coast=findViewById(R.id.edtransportayion_coast);
        edrto_expences=findViewById(R.id.edrto_expences);
        edinsurance_cost=findViewById(R.id.edinsurance_cost);
        edtaxes_penalty=findViewById(R.id.edtaxes_penalty);
        edrefurb_coast=findViewById(R.id.edrefurb_coast);
        edparking_charges=findViewById(R.id.edparking_charges);
        edtotal_coast=findViewById(R.id.edtotal_coast);





    }



    public void NEXT(View view) {
//
        StringRequest stringRequest = new StringRequest(Request.Method.POST, httpurl,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(Report.this, response, Toast.LENGTH_LONG).show();
                    Log.e("resp",String.valueOf(response));

                        try {
                            JSONArray jsonArray = new JSONArray(response);
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject itemList = jsonArray.getJSONObject(i);
                                edReference1.setText(itemList.getString("Ref_no"));
                                edBank.setText(itemList.getString("Bank_valuation_for"));
                                edContractno.setText(itemList.getString("contact_no"));
                                edRequestfrom.setText(itemList.getString("Request_from"));
                                edAssetMake.setText(itemList.getString("AssetMake"));
                                edAssetModel.setText(itemList.getString("Asset_model"));
                                edHMRKMR.setText(itemList.getString("HMR_KMR"));
                                edChassisNumber.setText(itemList.getString("Chassis_no"));
                                edEngineNumber.setText(itemList.getString("Engine_no"));
                                Log.e("items", String.valueOf(itemList));
                                //edTaxStatus.setText("asdf");
                                edTaxStatus.setText(itemList.getString("Tax_Status"));
                                //edpurpose1.setText("asdf");
                                edpurpose1.setText(itemList.getString("Purpose"));
                               //spurpose1 = itemList.getString("Purpose");
                                //Log.e("error",itemList.getString("Ref_no")+":"+itemList.getString("Bank_valuation_for")+":"+itemList.getString("contact_no")+":"+itemList.getString("Request_from"));
                                //Log.e("edpurpose",itemList.getString("Purpose")+"ggggg");
                                edrepossessiondate.setText(itemList.getString("Repossession_date"));
                                edrcno.setText(itemList.getString("RC_no"));
                                edrcstatus.setText(itemList.getString("RC_status"));
                                edYearofmfg.setText(itemList.getString("year_of_mfg"));
                                edInspector.setText(itemList.getString("Inspector"));
                                edLocation.setText(itemList.getString("Location"));
                                edRCFitnessValid.setText(itemList.getString("RC_Fitness_valid"));


                                int totalcost;
                                int Buyer_Biddersmargin;
                                Buyer_Biddersmargin = itemList.getInt("Buyer_Biddersmargin");
                                int warranty_cost= itemList.getInt("warranty_cost");
                                int Transporation_cost= itemList.getInt("Transporation_cost");
                                int RTO_Expenses= itemList.getInt("RTO_Expenses");
                                int insurance_cost= itemList.getInt("insurance_cost");
                                int Taxes_penalty= itemList.getInt("Taxes_penalty");
                                int Refurb_cost= itemList.getInt("Refurb_cost");

                              //  Log.e(String.valueOf(Buyer_Biddersmargin),":"+warranty_cost+"+"+Transporation_cost+":"+RTO_Expenses+":"+insurance_cost+":"+Taxes_penalty+":"+Refurb_cost);
                                totalcost = Buyer_Biddersmargin + warranty_cost + Transporation_cost + RTO_Expenses + insurance_cost + Taxes_penalty + Refurb_cost;
                               // Log.e(String.valueOf(totalcost),"total");
                                edbuyer.setText(itemList.getString("Buyer_Biddersmargin"));
                                edwarenty_coast.setText(itemList.getString("warranty_cost"));
                                edtransportayion_coast.setText(itemList.getString("Transporation_cost"));
                                edrto_expences.setText(itemList.getString("RTO_Expenses"));
                                edinsurance_cost.setText(itemList.getString("insurance_cost"));
                                edtaxes_penalty.setText(itemList.getString("Taxes_penalty"));
                                edrefurb_coast.setText(itemList.getString("Refurb_cost"));
                                edparking_charges.setText(itemList.getString("Parking_charges"));
                                edtotal_coast.setText(String.valueOf(totalcost));
                                //getting assessts descriptions
                                String ashttpurl = "http://192.168.43.16/Hackathon/getassesstdescription.php";
                                StringRequest stringRequest = new StringRequest(Request.Method.POST, ashttpurl,
                                        new com.android.volley.Response.Listener<String>() {
                                            @Override
                                            public void onResponse(String response) {
                                                Log.e("spinner response",response);

                                                if (response !="error"){
                                                    //Toast.makeText(Report.this, response, Toast.LENGTH_SHORT).show();
                                                    Log.e("res",response);
                                                    try {
                                                        int flag =0;
                                                        JSONArray jsonArray = new JSONArray(response);
                                                        for (int i = 0; i < jsonArray.length(); i++) {
                                                            JSONObject itemList = jsonArray.getJSONObject(i);
                                                            String AssName = itemList.getString("Assessors_name");
                                                            String Parameter = itemList.getString("parameter_name");
                                                            String Conditon = itemList.getString("condition_name");
                                                            Log.e(AssName,Parameter+":"+Conditon);
                                                            String result = AssName.replaceAll("[\\-\\+\\.\\^:,]","");
                                                            Log.e("result",result);
                                                         //   if (result.equals("Engine")) {
                                                               Log.e("error","i am ");
                                                               if (flag == 0) {
                                                                   flag++;
                                                                   Log.e("error","i am ");
                                                                   parSilencer.setText(Parameter);
                                                                   conSilencer.setText(Conditon);
                                                               } else if (flag == 1) {
                                                                   parAbnormalEngineNoise.setText(Parameter);
                                                                   conEngineNoise.setText(Conditon);
                                                                   flag++;
                                                               } else if (flag == 2) {
                                                                   parPlugs.setText(Parameter);
                                                                   conPlugs.setText(Conditon);
                                                                   flag++;
                                                               } else if (flag == 3) {

                                                                   flag++;
                                                                   parOil.setText(Parameter);
                                                                   conOil.setText(Conditon);
                                                               } else if (flag == 4) {
                                                                   parRadiotorCondensor.setText(Parameter);
                                                                   conRadiotorCondensor.setText(Conditon);
                                                                   flag++;
                                                               } else if (flag == 5) {
                                                                   parOilLeakage.setText(Parameter);
                                                                   conOilleakage.setText(Conditon);
                                                                   flag++;
                                                               } else if (flag == 6) {
                                                                   parFanBelts.setText(Parameter);
                                                                   confanbelts.setText(Conditon);
                                                                   flag++;
                                                               } else if (flag == 7) {
                                                                   parFilters.setText(Parameter);
                                                                   conFilters.setText(Conditon);
                                                                   flag++;
                                                               }

                                                           //}else {
                                                           //    Log.e("i","out");
                                                          // }
                                                        }
                                                    } catch (JSONException e) {
                                                        e.printStackTrace();
                                                    }


                                                        }else {
                                                    Toast.makeText(Report.this, response, Toast.LENGTH_LONG).show();
                                                    Log.e("sql",response);

                                                }
                                            }
                                        },
                                        new com.android.volley.Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError error) {
                                                //Toast.makeText(MainActivity.this, (CharSequence) error, Toast.LENGTH_LONG).show();
                                                Log.e(String.valueOf(error), "error");
                                            }
                                        }) {
                                    @Override
                                    protected Map<String, String> getParams() {
                                        Map<String, String> params = new HashMap<String, String>();
                                        //params.put("mainid",tempvalues.mainid);
                                        params.put("mainid",tempvalues.mainid);
                                        return params;
                                    }
                                };
                                // Creating RequestQueue.
                                RequestQueue requestQueue = Volley.newRequestQueue(Report.this);

                                // Adding the StringRequest object into requestQueue.
                                requestQueue.add(stringRequest);











                                //
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }



                    }

                },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Toast.makeText(MainActivity.this, (CharSequence) error, Toast.LENGTH_LONG).show();
                        Log.e(String.valueOf(error), "error");
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
             // tempvalues.mainid = "1";
                params.put("mainid",tempvalues.mainid);
                return params;
            }
        };
        // Creating RequestQueue.
        RequestQueue requestQueue = Volley.newRequestQueue(Report.this);

        // Adding the StringRequest object into requestQueue.
        requestQueue.add(stringRequest);
    }

    }


