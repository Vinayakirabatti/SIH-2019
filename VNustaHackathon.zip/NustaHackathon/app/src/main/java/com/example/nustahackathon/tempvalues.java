package com.example.nustahackathon;

public class tempvalues {


    static String mainid;
    static String cost_to_bidder_id;
}
