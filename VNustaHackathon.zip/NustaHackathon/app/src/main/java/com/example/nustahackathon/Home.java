package com.example.nustahackathon;

import android.content.Intent;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

public class Home extends AppCompatActivity {
    private DrawerLayout mdrawerLayout;
    private ActionBarDrawerToggle mtoggle;
    ImageView report;
    CardView Inspectorc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        mdrawerLayout = findViewById(R.id.drawer);
        mtoggle = new ActionBarDrawerToggle(this, mdrawerLayout,R.string.open,R.string.close);
        mdrawerLayout.addDrawerListener(mtoggle);
        mtoggle.syncState();
//        report=findViewById(R.id.report);
//
//        report.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent=new Intent(Home.this,Report.class);
//                //final String Reference = getIntent().getExtras().getString("Reference");
//                final String Bank = getIntent().getExtras().getString("Bank");
//                final String Contractno = getIntent().getExtras().getString("Contractno");
//                final String Requestfrom = getIntent().getExtras().getString("Requestfrom");
//                final String AssetMake = getIntent().getExtras().getString("AssetMake");
//                final String AssetModel = getIntent().getExtras().getString("AssetModel");
//                final String Yearofmfg = getIntent().getExtras().getString("Yearofmfg");
//                final String HMRKMR = getIntent().getExtras().getString("HMRKMR");
//                final String ChassisNumber = getIntent().getExtras().getString("ChassisNumber");
//                final String EngineNumber = getIntent().getExtras().getString("EngineNumber");
//                final String Inspector = getIntent().getExtras().getString("Inspector");
//                final String Location = getIntent().getExtras().getString("Location");
//                final String RCFitnessValid = getIntent().getExtras().getString("RCFitnessValid");
//                final String TaxStatus = getIntent().getExtras().getString("TaxStatus");
//                //intent.putExtra("Reference",Reference);
//                    intent.putExtra("Bank",Bank);
//                    intent.putExtra("Contractno",Contractno);
//                    intent.putExtra("Requestfrom",Requestfrom);
//                    intent.putExtra("AssetMake",AssetMake);
//                    intent.putExtra("AssetModel",AssetModel);
//                    intent.putExtra("Yearofmfg",Yearofmfg);
//                    intent.putExtra("HMRKMR",HMRKMR);
//                    intent.putExtra("ChassisNumber",ChassisNumber);
//                    intent.putExtra("EngineNumber",EngineNumber);
//                    intent.putExtra("Inspector",Inspector);
//                    intent.putExtra("Location",Location);
//                    intent.putExtra("RCFitnessValid",RCFitnessValid);
////                    intent.putExtra("TaxStatus",TaxStatus);
//                startActivity(intent);
//            }
//        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //Inspectorc=findViewById(R.id.inspectorc);
        mdrawerLayout.addDrawerListener(
                new DrawerLayout.DrawerListener() {
                    @Override
                    public void onDrawerSlide(View drawerView, float slideOffset) {
                        // Respond when the drawer's position changes
                    }

                    @Override
                    public void onDrawerOpened(View drawerView) {
                        // Respond when the drawer is opened
                    }

                    @Override
                    public void onDrawerClosed(View drawerView) {
                        // Respond when the drawer is closed
                    }

                    @Override
                    public void onDrawerStateChanged(int newState) {
                        // Respond when the drawer motion state changes
                    }
                }
        );
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mtoggle.onOptionsItemSelected(item))
        {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void Inspection(View view) {
        Intent s=new Intent(Home.this,inspectionlist.class);
        startActivity(s);
        finish();

    }

    public void Report(View view) {
        Intent intent=new Intent(Home.this,Report.class);
//        final String purpose;
//        if(getIntent().getExtras().getString("purpose") == null ){
//            Log.e("null","pur");
//            purpose = "a";
//        }else {
//            purpose = getIntent().getExtras().getString("purpose");
//        }


//        final String Bank = getIntent().getExtras().getString("Bank");
//        final String Contractno = getIntent().getExtras().getString("Contractno");
//        final String Requestfrom = getIntent().getExtras().getString("Requestfrom");
//        final String AssetMake = getIntent().getExtras().getString("AssetMake");
//        final String AssetModel = getIntent().getExtras().getString("AssetModel");
//        final String Yearofmfg = getIntent().getExtras().getString("Yearofmfg");
//        final String HMRKMR = getIntent().getExtras().getString("HMRKMR");
//        final String ChassisNumber = getIntent().getExtras().getString("ChassisNumber");
//        final String EngineNumber = getIntent().getExtras().getString("EngineNumber");
//        final String Inspector = getIntent().getExtras().getString("Inspector");
//        final String Location = getIntent().getExtras().getString("Location");
//        final String RCFitnessValid = getIntent().getExtras().getString("RCFitnessValid");
//        final String TaxStatus = getIntent().getExtras().getString("TaxStatus");
//        intent.putExtra("purpose",purpose);
        
//        intent.putExtra("Bank",Bank);
//        intent.putExtra("Contractno",Contractno);
//        intent.putExtra("Requestfrom",Requestfrom);
//        intent.putExtra("AssetMake",AssetMake);
//        intent.putExtra("AssetModel",AssetModel);
//        intent.putExtra("Yearofmfg",Yearofmfg);
//        intent.putExtra("HMRKMR",HMRKMR);
//        intent.putExtra("ChassisNumber",ChassisNumber);
//        intent.putExtra("EngineNumber",EngineNumber);
//        intent.putExtra("Inspector",Inspector);
//        intent.putExtra("Location",Location);
//        intent.putExtra("RCFitnessValid",RCFitnessValid);
//        intent.putExtra("TaxStatus",TaxStatus);
        startActivity(intent);
        finish();
    }

    public void tutorial(View view) {
        Intent s=new Intent(Home.this,reporttut.class);
        startActivity(s);
    }
}
