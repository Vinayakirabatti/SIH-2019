package com.example.nustahackathon;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;

public class Camera extends AppCompatActivity {
    Button button1,button2,button3,button4,button5,button6,button7,button8;
    Button upload;
    private StorageReference mstorage;
    private ImageView image1, image2, image3,image4,image5,image6,image7,image8;
    private ImageView[] image = { image1, image2, image3,image4,image5,image6,image7,image8 };
    private Intent intent1, intent2, intent3,intent4,intent5,intent6,intent7,intent8;
    private Intent[] intent = { intent1, intent2, intent3,intent4,intent5,intent6,intent7,intent8 };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);
        mstorage= FirebaseStorage.getInstance().getReference();
        button1=findViewById(R.id.button1);
        button2=findViewById(R.id.button2);
        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);
        button5=findViewById(R.id.button5);
        button6=findViewById(R.id.button6);
        button7=findViewById(R.id.button7);
        button8=findViewById(R.id.button8);
        image1=findViewById(R.id.image1);
        image2=findViewById(R.id.image2);
        image3=findViewById(R.id.image3);
        image4=findViewById(R.id.image4);
        image5=findViewById(R.id.image5);
        image6=findViewById(R.id.image6);
        image7=findViewById(R.id.image7);
        image8=findViewById(R.id.image8);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent1=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent1,1);
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent2=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent2,2);
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent3=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent3,3);
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent4=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent4,4);
            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent5=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent5,5);
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent6=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent6,6);
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent7=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent7,7);
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent8=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent8,8);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK &&requestCode==1 &&button1.isEnabled()){
            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            File file = new File(path,"example1.jpg");
            Uri outputFileUri = Uri.fromFile( file );
            Bitmap bitmap=(Bitmap)data.getExtras().get("data");
            image1.setImageBitmap(bitmap);
            intent1.putExtra( MediaStore.EXTRA_OUTPUT, outputFileUri );
            Toast.makeText(this, file.toString(), Toast.LENGTH_SHORT).show();
            StorageReference filepath=mstorage.child("photos").child(outputFileUri.getLastPathSegment());
            filepath.putFile(outputFileUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Toast.makeText(Camera.this, "Uploaded", Toast.LENGTH_SHORT).show();
                }
            });
        }
        if(resultCode==RESULT_OK &&requestCode==2 &&button2.isEnabled()){
            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            File file = new File(path,"example2.jpg");
            Uri outputFileUri = Uri.fromFile( file );
            Bitmap bitmap=(Bitmap)data.getExtras().get("data");
            image2.setImageBitmap(bitmap);
            intent2.putExtra( MediaStore.EXTRA_OUTPUT, outputFileUri );
            Toast.makeText(this, file.toString(), Toast.LENGTH_SHORT).show();
        }
        if(resultCode==RESULT_OK &&requestCode==3 &&button3.isEnabled()){
            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            File file = new File(path,"example3.jpg");
            Uri outputFileUri = Uri.fromFile( file );
            Bitmap bitmap=(Bitmap)data.getExtras().get("data");
            image3.setImageBitmap(bitmap);
            intent3.putExtra( MediaStore.EXTRA_OUTPUT, outputFileUri );
            Toast.makeText(this, file.toString(), Toast.LENGTH_SHORT).show();
        }
        if(resultCode==RESULT_OK &&requestCode==4 &&button4.isEnabled()){
            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            File file = new File(path,"example4.jpg");
            Uri outputFileUri = Uri.fromFile( file );
            Bitmap bitmap=(Bitmap)data.getExtras().get("data");
            image4.setImageBitmap(bitmap);
            intent4.putExtra( MediaStore.EXTRA_OUTPUT, outputFileUri );
            Toast.makeText(this, file.toString(), Toast.LENGTH_SHORT).show();
        }
        if(resultCode==RESULT_OK &&requestCode==5 &&button5.isEnabled()){
            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            File file = new File(path,"example5.jpg");
            Uri outputFileUri = Uri.fromFile( file );
            Bitmap bitmap=(Bitmap)data.getExtras().get("data");
            image5.setImageBitmap(bitmap);
            intent5.putExtra( MediaStore.EXTRA_OUTPUT, outputFileUri );
            Toast.makeText(this, file.toString(), Toast.LENGTH_SHORT).show();
        }
        if(resultCode==RESULT_OK &&requestCode==6 &&button6.isEnabled()){
            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            File file = new File(path,"example6.jpg");
            Uri outputFileUri = Uri.fromFile( file );
            Bitmap bitmap=(Bitmap)data.getExtras().get("data");
            image6.setImageBitmap(bitmap);
            intent6.putExtra( MediaStore.EXTRA_OUTPUT, outputFileUri );
            Toast.makeText(this, file.toString(), Toast.LENGTH_SHORT).show();
        }
        if(resultCode==RESULT_OK &&requestCode==7 &&button7.isEnabled()){
            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            File file = new File(path,"example7.jpg");
            Uri outputFileUri = Uri.fromFile( file );
            Bitmap bitmap=(Bitmap)data.getExtras().get("data");
            image7.setImageBitmap(bitmap);
            intent7.putExtra( MediaStore.EXTRA_OUTPUT, outputFileUri );
            Toast.makeText(this, file.toString(), Toast.LENGTH_SHORT).show();
        }
        if(resultCode==RESULT_OK &&requestCode==8 &&button8.isEnabled()){
            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            File file = new File(path,"example8.jpg");
            Uri outputFileUri = Uri.fromFile( file );
            Bitmap bitmap=(Bitmap)data.getExtras().get("data");
            image8.setImageBitmap(bitmap);
            intent8.putExtra( MediaStore.EXTRA_OUTPUT, outputFileUri );
            Toast.makeText(this, file.toString(), Toast.LENGTH_SHORT).show();
        }
    }
    }

