package com.example.gridlayout;

import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import fr.ganfra.materialspinner.MaterialSpinner;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
   private GridLayout mainGrid;
   private String g;
   private String silencer="",engine="",plugs="",oil="",radiator_condenser="",oil_leakage ="",fan_belts="",filters="",suspension_noise_whileDriving_front_rear="",steering_lock="",wheel_alignment_balancing_wobbling="",steering_operation="",pedal_operation="",brakes_and_hand_brake="",gear_engagement="",differential_and_crown_rearWheel_drive="",instrument_cluster_warningLights_gauges="",alternator="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainGrid = findViewById(R.id.mainGrid);


        setSingleEvent(mainGrid);
    }

    public void setSingleEvent(GridLayout mainGrid) {
        for (int i = 0; i < mainGrid.getChildCount(); i++) {
            CardView cardView = (CardView) mainGrid.getChildAt(i);
            final int ii = i;
            cardView.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                       // Toast.makeText(MainActivity.this, "this"+ii, Toast.LENGTH_SHORT).show();
                    if (ii == 0) {
                        final Dialog dialog=new Dialog(MainActivity.this);
                        dialog.setContentView(R.layout.popup);
                        dialog.setTitle("Engine");

                        MaterialSpinner Silencer = dialog.findViewById(R.id.Silencer);
                        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Silencer.setAdapter(adapter);
                        if(silencer!="") {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Abnormal_Engine_Noise = dialog.findViewById(R.id.Abnormal_Engine_Noise);
                        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Abnormal_Engine_Noise.setAdapter(adapter1);
                        if(engine != "" ) {
                            int pos = adapter.getPosition(engine);
                            pos++;
                            Abnormal_Engine_Noise.setSelection(pos);
                        }

                        MaterialSpinner Plugs = dialog.findViewById(R.id.Plugs);
                        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Plugs.setAdapter(adapter2);
                        if(plugs != "" ) {
                            int pos = adapter.getPosition(plugs);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil = dialog.findViewById(R.id.Oil);
                        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil.setAdapter(adapter3);
                        if(oil != "" ) {
                            int pos = adapter.getPosition(oil);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Radiator_Condenser = dialog.findViewById(R.id.Radiator_Condenser);
                        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Radiator_Condenser.setAdapter(adapter4);
                        if(radiator_condenser != "" ) {
                            int pos = adapter.getPosition(radiator_condenser);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil_Leakage = dialog.findViewById(R.id.Oil_Leakage);
                        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil_Leakage.setAdapter(adapter5);
                        if(oil_leakage != "" ) {
                            int pos = adapter.getPosition(oil_leakage);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Fan_Belts = dialog.findViewById(R.id.Fan_Belts);
                        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Fan_Belts.setAdapter(adapter6);
                        if(fan_belts != "" ) {
                            int pos = adapter.getPosition(fan_belts);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Filters = dialog.findViewById(R.id.Filters);
                        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Filters.setAdapter(adapter7);
                        if(filters != "" ) {
                            int pos = adapter.getPosition(filters);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Suspension_Noise_WhileDriving_Front_Rear = dialog.findViewById(R.id.Suspension_Noise_WhileDriving_Front_Rear);
                        ArrayAdapter<CharSequence> adapter8 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Suspension_Noise_WhileDriving_Front_Rear.setAdapter(adapter8);
                        if(suspension_noise_whileDriving_front_rear != "" ) {
                            int pos = adapter.getPosition(suspension_noise_whileDriving_front_rear);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Lock = dialog.findViewById(R.id.Steering_Lock);
                        ArrayAdapter<CharSequence> adapter9 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Lock.setAdapter(adapter9);
                        if(steering_lock != "" ) {
                            int pos = adapter.getPosition(steering_lock);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Wheel_Alignment_Balancing_Wobbling = dialog.findViewById(R.id.Wheel_Alignment_Balancing_Wobbling);
                        ArrayAdapter<CharSequence> adapter10 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Wheel_Alignment_Balancing_Wobbling.setAdapter(adapter10);
                        if(wheel_alignment_balancing_wobbling != "" ) {
                            int pos = adapter.getPosition(wheel_alignment_balancing_wobbling);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Operation = dialog.findViewById(R.id.Steering_Operation);
                        ArrayAdapter<CharSequence> adapter11 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Operation.setAdapter(adapter11);
                        if(steering_operation != "" ) {
                            int pos = adapter.getPosition(steering_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Pedal_Operation = dialog.findViewById(R.id.Pedal_Operation);
                        ArrayAdapter<CharSequence> adapter12 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Pedal_Operation.setAdapter(adapter12);
                        if(pedal_operation != "" ) {
                            int pos = adapter.getPosition(pedal_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Brakes_and_Hand_Brake = dialog.findViewById(R.id.Brakes_and_Hand_Brake);
                        ArrayAdapter<CharSequence> adapter13 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Brakes_and_Hand_Brake.setAdapter(adapter13);
                        if(brakes_and_hand_brake != "" ) {
                            int pos = adapter.getPosition(brakes_and_hand_brake);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Gear_Engagement = dialog.findViewById(R.id.Gear_Engagement);
                        ArrayAdapter<CharSequence> adapter14 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Gear_Engagement.setAdapter(adapter14);
                        if(gear_engagement != "" ) {
                            int pos = adapter.getPosition(gear_engagement);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Differential_And_Crown_RearWheel_Drive = dialog.findViewById(R.id.Differential_And_Crown_RearWheel_Drive);
                        ArrayAdapter<CharSequence> adapter15 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Differential_And_Crown_RearWheel_Drive.setAdapter(adapter15);
                        if(differential_and_crown_rearWheel_drive != "" ) {
                            int pos = adapter.getPosition(differential_and_crown_rearWheel_drive);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Instrument_Cluster_WarningLights_Gauges = dialog.findViewById(R.id.Instrument_Cluster_WarningLights_Gauges);
                        ArrayAdapter<CharSequence> adapter16 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Instrument_Cluster_WarningLights_Gauges.setAdapter(adapter16);
                        if(instrument_cluster_warningLights_gauges != "" ) {
                            int pos = adapter.getPosition(instrument_cluster_warningLights_gauges);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Alternator = dialog.findViewById(R.id.Alternator);
                        ArrayAdapter<CharSequence> adapter17 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Alternator.setAdapter(adapter17);
                        if(alternator != "" ) {
                            int pos = adapter.getPosition(alternator);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        Silencer.setOnItemSelectedListener(MainActivity.this);
                        Abnormal_Engine_Noise.setOnItemSelectedListener(MainActivity.this);
                        Plugs.setOnItemSelectedListener(MainActivity.this);
                        Oil.setOnItemSelectedListener(MainActivity.this);
                        Radiator_Condenser.setOnItemSelectedListener(MainActivity.this);
                        Oil_Leakage.setOnItemSelectedListener(MainActivity.this);
                        Fan_Belts.setOnItemSelectedListener(MainActivity.this);
                        Filters.setOnItemSelectedListener(MainActivity.this);
                        Suspension_Noise_WhileDriving_Front_Rear.setOnItemSelectedListener(MainActivity.this);
                        Steering_Lock.setOnItemSelectedListener(MainActivity.this);
                        Wheel_Alignment_Balancing_Wobbling.setOnItemSelectedListener(MainActivity.this);
                        Steering_Operation.setOnItemSelectedListener(MainActivity.this);
                        Pedal_Operation.setOnItemSelectedListener(MainActivity.this);
                        Brakes_and_Hand_Brake.setOnItemSelectedListener(MainActivity.this);
                        Gear_Engagement.setOnItemSelectedListener(MainActivity.this);
                        Differential_And_Crown_RearWheel_Drive.setOnItemSelectedListener(MainActivity.this);
                        Alternator.setOnItemSelectedListener(MainActivity.this);



                        Button save;
                        save=dialog.findViewById(R.id.save);
                        save.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(MainActivity.this, g+"Saved", Toast.LENGTH_SHORT).show();
                                ArrayList<String> array=new ArrayList<>();

                                array.add(silencer);
                                array.add(engine);

                                Intent s=new Intent(MainActivity.this,Main2Activity.class);
                                s.putExtra("1",array);
                                startActivity(s);


                            }


                        });
                        dialog.show();

                    } else if (ii == 1) {
                        final Dialog dialog=new Dialog(MainActivity.this);
                        dialog.setContentView(R.layout.popup);
                        dialog.setTitle("Engine");

                        MaterialSpinner Silencer = dialog.findViewById(R.id.Silencer);
                        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Silencer.setAdapter(adapter);
                        if(silencer != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Abnormal_Engine_Noise = dialog.findViewById(R.id.Abnormal_Engine_Noise);
                        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Abnormal_Engine_Noise.setAdapter(adapter1);
                        if(engine != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Plugs = dialog.findViewById(R.id.Plugs);
                        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Plugs.setAdapter(adapter2);
                        if(plugs != "" ) {
                            int pos = adapter.getPosition(plugs);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil = dialog.findViewById(R.id.Oil);
                        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil.setAdapter(adapter3);
                        if(oil != "" ) {
                            int pos = adapter.getPosition(oil);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Radiator_Condenser = dialog.findViewById(R.id.Radiator_Condenser);
                        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Radiator_Condenser.setAdapter(adapter4);
                        if(radiator_condenser != "" ) {
                            int pos = adapter.getPosition(radiator_condenser);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil_Leakage = dialog.findViewById(R.id.Oil_Leakage);
                        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil_Leakage.setAdapter(adapter5);
                        if(oil_leakage != "" ) {
                            int pos = adapter.getPosition(oil_leakage);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Fan_Belts = dialog.findViewById(R.id.Fan_Belts);
                        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Fan_Belts.setAdapter(adapter6);
                        if(fan_belts != "" ) {
                            int pos = adapter.getPosition(fan_belts);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Filters = dialog.findViewById(R.id.Filters);
                        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Filters.setAdapter(adapter7);
                        if(filters != "" ) {
                            int pos = adapter.getPosition(filters);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Suspension_Noise_WhileDriving_Front_Rear = dialog.findViewById(R.id.Suspension_Noise_WhileDriving_Front_Rear);
                        ArrayAdapter<CharSequence> adapter8 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Suspension_Noise_WhileDriving_Front_Rear.setAdapter(adapter8);
                        if(suspension_noise_whileDriving_front_rear != "" ) {
                            int pos = adapter.getPosition(suspension_noise_whileDriving_front_rear);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Lock = dialog.findViewById(R.id.Steering_Lock);
                        ArrayAdapter<CharSequence> adapter9 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Lock.setAdapter(adapter9);
                        if(steering_lock != "" ) {
                            int pos = adapter.getPosition(steering_lock);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Wheel_Alignment_Balancing_Wobbling = dialog.findViewById(R.id.Wheel_Alignment_Balancing_Wobbling);
                        ArrayAdapter<CharSequence> adapter10 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Wheel_Alignment_Balancing_Wobbling.setAdapter(adapter10);
                        if(wheel_alignment_balancing_wobbling != "" ) {
                            int pos = adapter.getPosition(wheel_alignment_balancing_wobbling);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Operation = dialog.findViewById(R.id.Steering_Operation);
                        ArrayAdapter<CharSequence> adapter11 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Operation.setAdapter(adapter11);
                        if(steering_operation != "" ) {
                            int pos = adapter.getPosition(steering_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Pedal_Operation = dialog.findViewById(R.id.Pedal_Operation);
                        ArrayAdapter<CharSequence> adapter12 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Pedal_Operation.setAdapter(adapter12);
                        if(pedal_operation != "" ) {
                            int pos = adapter.getPosition(pedal_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Brakes_and_Hand_Brake = dialog.findViewById(R.id.Brakes_and_Hand_Brake);
                        ArrayAdapter<CharSequence> adapter13 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Brakes_and_Hand_Brake.setAdapter(adapter13);
                        if(brakes_and_hand_brake != "" ) {
                            int pos = adapter.getPosition(brakes_and_hand_brake);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Gear_Engagement = dialog.findViewById(R.id.Gear_Engagement);
                        ArrayAdapter<CharSequence> adapter14 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Gear_Engagement.setAdapter(adapter14);
                        if(gear_engagement != "" ) {
                            int pos = adapter.getPosition(gear_engagement);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Differential_And_Crown_RearWheel_Drive = dialog.findViewById(R.id.Differential_And_Crown_RearWheel_Drive);
                        ArrayAdapter<CharSequence> adapter15 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Differential_And_Crown_RearWheel_Drive.setAdapter(adapter15);
                        if(differential_and_crown_rearWheel_drive != "" ) {
                            int pos = adapter.getPosition(differential_and_crown_rearWheel_drive);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Instrument_Cluster_WarningLights_Gauges = dialog.findViewById(R.id.Instrument_Cluster_WarningLights_Gauges);
                        ArrayAdapter<CharSequence> adapter16 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Instrument_Cluster_WarningLights_Gauges.setAdapter(adapter16);
                        if(instrument_cluster_warningLights_gauges != "" ) {
                            int pos = adapter.getPosition(instrument_cluster_warningLights_gauges);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Alternator = dialog.findViewById(R.id.Alternator);
                        ArrayAdapter<CharSequence> adapter17 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Alternator.setAdapter(adapter17);
                        if(alternator != "" ) {
                            int pos = adapter.getPosition(alternator);
                            pos++;
                            Silencer.setSelection(pos);
                        }


                        Abnormal_Engine_Noise.setOnItemSelectedListener(MainActivity.this);
                        Plugs.setOnItemSelectedListener(MainActivity.this);
                        Oil.setOnItemSelectedListener(MainActivity.this);
                        Radiator_Condenser.setOnItemSelectedListener(MainActivity.this);
                        Oil_Leakage.setOnItemSelectedListener(MainActivity.this);
                        Fan_Belts.setOnItemSelectedListener(MainActivity.this);
                        Filters.setOnItemSelectedListener(MainActivity.this);
                        Suspension_Noise_WhileDriving_Front_Rear.setOnItemSelectedListener(MainActivity.this);
                        Steering_Lock.setOnItemSelectedListener(MainActivity.this);
                        Wheel_Alignment_Balancing_Wobbling.setOnItemSelectedListener(MainActivity.this);
                        Steering_Operation.setOnItemSelectedListener(MainActivity.this);
                        Pedal_Operation.setOnItemSelectedListener(MainActivity.this);
                        Brakes_and_Hand_Brake.setOnItemSelectedListener(MainActivity.this);
                        Gear_Engagement.setOnItemSelectedListener(MainActivity.this);
                        Differential_And_Crown_RearWheel_Drive.setOnItemSelectedListener(MainActivity.this);
                        Alternator.setOnItemSelectedListener(MainActivity.this);



                        Button save;
                        save=dialog.findViewById(R.id.save);
                        save.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(MainActivity.this, g+"Saved", Toast.LENGTH_SHORT).show();
                                ArrayList<String> array=new ArrayList<>();

                                array.add(silencer);
                                array.add(engine);

                                Intent s=new Intent(MainActivity.this,Main2Activity.class);
                                s.putExtra("1",array);
                                startActivity(s);


                            }


                        });
                        dialog.show();

                    } else if (ii == 2) {
                        final Dialog dialog=new Dialog(MainActivity.this);
                        dialog.setContentView(R.layout.popup);
                        dialog.setTitle("Engine");

                        MaterialSpinner Silencer = dialog.findViewById(R.id.Silencer);
                        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Silencer.setAdapter(adapter);
                        if(silencer != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Abnormal_Engine_Noise = dialog.findViewById(R.id.Abnormal_Engine_Noise);
                        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Abnormal_Engine_Noise.setAdapter(adapter1);
                        if(engine != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Plugs = dialog.findViewById(R.id.Plugs);
                        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Plugs.setAdapter(adapter2);
                        if(plugs != "" ) {
                            int pos = adapter.getPosition(plugs);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil = dialog.findViewById(R.id.Oil);
                        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil.setAdapter(adapter3);
                        if(oil != "" ) {
                            int pos = adapter.getPosition(oil);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Radiator_Condenser = dialog.findViewById(R.id.Radiator_Condenser);
                        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Radiator_Condenser.setAdapter(adapter4);
                        if(radiator_condenser != "" ) {
                            int pos = adapter.getPosition(radiator_condenser);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil_Leakage = dialog.findViewById(R.id.Oil_Leakage);
                        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil_Leakage.setAdapter(adapter5);
                        if(oil_leakage != "" ) {
                            int pos = adapter.getPosition(oil_leakage);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Fan_Belts = dialog.findViewById(R.id.Fan_Belts);
                        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Fan_Belts.setAdapter(adapter6);
                        if(fan_belts != "" ) {
                            int pos = adapter.getPosition(fan_belts);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Filters = dialog.findViewById(R.id.Filters);
                        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Filters.setAdapter(adapter7);
                        if(filters != "" ) {
                            int pos = adapter.getPosition(filters);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Suspension_Noise_WhileDriving_Front_Rear = dialog.findViewById(R.id.Suspension_Noise_WhileDriving_Front_Rear);
                        ArrayAdapter<CharSequence> adapter8 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Suspension_Noise_WhileDriving_Front_Rear.setAdapter(adapter8);
                        if(suspension_noise_whileDriving_front_rear != "" ) {
                            int pos = adapter.getPosition(suspension_noise_whileDriving_front_rear);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Lock = dialog.findViewById(R.id.Steering_Lock);
                        ArrayAdapter<CharSequence> adapter9 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Lock.setAdapter(adapter9);
                        if(steering_lock != "" ) {
                            int pos = adapter.getPosition(steering_lock);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Wheel_Alignment_Balancing_Wobbling = dialog.findViewById(R.id.Wheel_Alignment_Balancing_Wobbling);
                        ArrayAdapter<CharSequence> adapter10 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Wheel_Alignment_Balancing_Wobbling.setAdapter(adapter10);
                        if(wheel_alignment_balancing_wobbling != "" ) {
                            int pos = adapter.getPosition(wheel_alignment_balancing_wobbling);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Operation = dialog.findViewById(R.id.Steering_Operation);
                        ArrayAdapter<CharSequence> adapter11 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Operation.setAdapter(adapter11);
                        if(steering_operation != "" ) {
                            int pos = adapter.getPosition(steering_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Pedal_Operation = dialog.findViewById(R.id.Pedal_Operation);
                        ArrayAdapter<CharSequence> adapter12 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Pedal_Operation.setAdapter(adapter12);
                        if(pedal_operation != "" ) {
                            int pos = adapter.getPosition(pedal_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Brakes_and_Hand_Brake = dialog.findViewById(R.id.Brakes_and_Hand_Brake);
                        ArrayAdapter<CharSequence> adapter13 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Brakes_and_Hand_Brake.setAdapter(adapter13);
                        if(brakes_and_hand_brake != "" ) {
                            int pos = adapter.getPosition(brakes_and_hand_brake);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Gear_Engagement = dialog.findViewById(R.id.Gear_Engagement);
                        ArrayAdapter<CharSequence> adapter14 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Gear_Engagement.setAdapter(adapter14);
                        if(gear_engagement != "" ) {
                            int pos = adapter.getPosition(gear_engagement);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Differential_And_Crown_RearWheel_Drive = dialog.findViewById(R.id.Differential_And_Crown_RearWheel_Drive);
                        ArrayAdapter<CharSequence> adapter15 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Differential_And_Crown_RearWheel_Drive.setAdapter(adapter15);
                        if(differential_and_crown_rearWheel_drive != "" ) {
                            int pos = adapter.getPosition(differential_and_crown_rearWheel_drive);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Instrument_Cluster_WarningLights_Gauges = dialog.findViewById(R.id.Instrument_Cluster_WarningLights_Gauges);
                        ArrayAdapter<CharSequence> adapter16 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Instrument_Cluster_WarningLights_Gauges.setAdapter(adapter16);
                        if(instrument_cluster_warningLights_gauges != "" ) {
                            int pos = adapter.getPosition(instrument_cluster_warningLights_gauges);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Alternator = dialog.findViewById(R.id.Alternator);
                        ArrayAdapter<CharSequence> adapter17 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Alternator.setAdapter(adapter17);
                        if(alternator != "" ) {
                            int pos = adapter.getPosition(alternator);
                            pos++;
                            Silencer.setSelection(pos);
                        }


                        Abnormal_Engine_Noise.setOnItemSelectedListener(MainActivity.this);
                        Plugs.setOnItemSelectedListener(MainActivity.this);
                        Oil.setOnItemSelectedListener(MainActivity.this);
                        Radiator_Condenser.setOnItemSelectedListener(MainActivity.this);
                        Oil_Leakage.setOnItemSelectedListener(MainActivity.this);
                        Fan_Belts.setOnItemSelectedListener(MainActivity.this);
                        Filters.setOnItemSelectedListener(MainActivity.this);
                        Suspension_Noise_WhileDriving_Front_Rear.setOnItemSelectedListener(MainActivity.this);
                        Steering_Lock.setOnItemSelectedListener(MainActivity.this);
                        Wheel_Alignment_Balancing_Wobbling.setOnItemSelectedListener(MainActivity.this);
                        Steering_Operation.setOnItemSelectedListener(MainActivity.this);
                        Pedal_Operation.setOnItemSelectedListener(MainActivity.this);
                        Brakes_and_Hand_Brake.setOnItemSelectedListener(MainActivity.this);
                        Gear_Engagement.setOnItemSelectedListener(MainActivity.this);
                        Differential_And_Crown_RearWheel_Drive.setOnItemSelectedListener(MainActivity.this);
                        Alternator.setOnItemSelectedListener(MainActivity.this);



                        Button save;
                        save=dialog.findViewById(R.id.save);
                        save.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(MainActivity.this, g+"Saved", Toast.LENGTH_SHORT).show();
                                ArrayList<String> array=new ArrayList<>();

                                array.add(silencer);
                                array.add(engine);

                                Intent s=new Intent(MainActivity.this,Main2Activity.class);
                                s.putExtra("1",array);
                                startActivity(s);


                            }


                        });
                        dialog.show();

                    } else if (ii == 3) {
                        final Dialog dialog=new Dialog(MainActivity.this);
                        dialog.setContentView(R.layout.popup);
                        dialog.setTitle("Engine");

                        MaterialSpinner Silencer = dialog.findViewById(R.id.Silencer);
                        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Silencer.setAdapter(adapter);
                        if(silencer != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Abnormal_Engine_Noise = dialog.findViewById(R.id.Abnormal_Engine_Noise);
                        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Abnormal_Engine_Noise.setAdapter(adapter1);
                        if(engine != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Plugs = dialog.findViewById(R.id.Plugs);
                        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Plugs.setAdapter(adapter2);
                        if(plugs != "" ) {
                            int pos = adapter.getPosition(plugs);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil = dialog.findViewById(R.id.Oil);
                        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil.setAdapter(adapter3);
                        if(oil != "" ) {
                            int pos = adapter.getPosition(oil);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Radiator_Condenser = dialog.findViewById(R.id.Radiator_Condenser);
                        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Radiator_Condenser.setAdapter(adapter4);
                        if(radiator_condenser != "" ) {
                            int pos = adapter.getPosition(radiator_condenser);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil_Leakage = dialog.findViewById(R.id.Oil_Leakage);
                        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil_Leakage.setAdapter(adapter5);
                        if(oil_leakage != "" ) {
                            int pos = adapter.getPosition(oil_leakage);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Fan_Belts = dialog.findViewById(R.id.Fan_Belts);
                        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Fan_Belts.setAdapter(adapter6);
                        if(fan_belts != "" ) {
                            int pos = adapter.getPosition(fan_belts);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Filters = dialog.findViewById(R.id.Filters);
                        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Filters.setAdapter(adapter7);
                        if(filters != "" ) {
                            int pos = adapter.getPosition(filters);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Suspension_Noise_WhileDriving_Front_Rear = dialog.findViewById(R.id.Suspension_Noise_WhileDriving_Front_Rear);
                        ArrayAdapter<CharSequence> adapter8 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Suspension_Noise_WhileDriving_Front_Rear.setAdapter(adapter8);
                        if(suspension_noise_whileDriving_front_rear != "" ) {
                            int pos = adapter.getPosition(suspension_noise_whileDriving_front_rear);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Lock = dialog.findViewById(R.id.Steering_Lock);
                        ArrayAdapter<CharSequence> adapter9 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Lock.setAdapter(adapter9);
                        if(steering_lock != "" ) {
                            int pos = adapter.getPosition(steering_lock);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Wheel_Alignment_Balancing_Wobbling = dialog.findViewById(R.id.Wheel_Alignment_Balancing_Wobbling);
                        ArrayAdapter<CharSequence> adapter10 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Wheel_Alignment_Balancing_Wobbling.setAdapter(adapter10);
                        if(wheel_alignment_balancing_wobbling != "" ) {
                            int pos = adapter.getPosition(wheel_alignment_balancing_wobbling);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Operation = dialog.findViewById(R.id.Steering_Operation);
                        ArrayAdapter<CharSequence> adapter11 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Operation.setAdapter(adapter11);
                        if(steering_operation != "" ) {
                            int pos = adapter.getPosition(steering_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Pedal_Operation = dialog.findViewById(R.id.Pedal_Operation);
                        ArrayAdapter<CharSequence> adapter12 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Pedal_Operation.setAdapter(adapter12);
                        if(pedal_operation != "" ) {
                            int pos = adapter.getPosition(pedal_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Brakes_and_Hand_Brake = dialog.findViewById(R.id.Brakes_and_Hand_Brake);
                        ArrayAdapter<CharSequence> adapter13 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Brakes_and_Hand_Brake.setAdapter(adapter13);
                        if(brakes_and_hand_brake != "" ) {
                            int pos = adapter.getPosition(brakes_and_hand_brake);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Gear_Engagement = dialog.findViewById(R.id.Gear_Engagement);
                        ArrayAdapter<CharSequence> adapter14 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Gear_Engagement.setAdapter(adapter14);
                        if(gear_engagement != "" ) {
                            int pos = adapter.getPosition(gear_engagement);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Differential_And_Crown_RearWheel_Drive = dialog.findViewById(R.id.Differential_And_Crown_RearWheel_Drive);
                        ArrayAdapter<CharSequence> adapter15 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Differential_And_Crown_RearWheel_Drive.setAdapter(adapter15);
                        if(differential_and_crown_rearWheel_drive != "" ) {
                            int pos = adapter.getPosition(differential_and_crown_rearWheel_drive);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Instrument_Cluster_WarningLights_Gauges = dialog.findViewById(R.id.Instrument_Cluster_WarningLights_Gauges);
                        ArrayAdapter<CharSequence> adapter16 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Instrument_Cluster_WarningLights_Gauges.setAdapter(adapter16);
                        if(instrument_cluster_warningLights_gauges != "" ) {
                            int pos = adapter.getPosition(instrument_cluster_warningLights_gauges);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Alternator = dialog.findViewById(R.id.Alternator);
                        ArrayAdapter<CharSequence> adapter17 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Alternator.setAdapter(adapter17);
                        if(alternator != "" ) {
                            int pos = adapter.getPosition(alternator);
                            pos++;
                            Silencer.setSelection(pos);
                        }


                        Abnormal_Engine_Noise.setOnItemSelectedListener(MainActivity.this);
                        Plugs.setOnItemSelectedListener(MainActivity.this);
                        Oil.setOnItemSelectedListener(MainActivity.this);
                        Radiator_Condenser.setOnItemSelectedListener(MainActivity.this);
                        Oil_Leakage.setOnItemSelectedListener(MainActivity.this);
                        Fan_Belts.setOnItemSelectedListener(MainActivity.this);
                        Filters.setOnItemSelectedListener(MainActivity.this);
                        Suspension_Noise_WhileDriving_Front_Rear.setOnItemSelectedListener(MainActivity.this);
                        Steering_Lock.setOnItemSelectedListener(MainActivity.this);
                        Wheel_Alignment_Balancing_Wobbling.setOnItemSelectedListener(MainActivity.this);
                        Steering_Operation.setOnItemSelectedListener(MainActivity.this);
                        Pedal_Operation.setOnItemSelectedListener(MainActivity.this);
                        Brakes_and_Hand_Brake.setOnItemSelectedListener(MainActivity.this);
                        Gear_Engagement.setOnItemSelectedListener(MainActivity.this);
                        Differential_And_Crown_RearWheel_Drive.setOnItemSelectedListener(MainActivity.this);
                        Alternator.setOnItemSelectedListener(MainActivity.this);



                        Button save;
                        save=dialog.findViewById(R.id.save);
                        save.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(MainActivity.this, g+"Saved", Toast.LENGTH_SHORT).show();
                                ArrayList<String> array=new ArrayList<>();

                                array.add(silencer);
                                array.add(engine);

                                Intent s=new Intent(MainActivity.this,Main2Activity.class);
                                s.putExtra("1",array);
                                startActivity(s);


                            }


                        });
                        dialog.show();

                    } else if (ii == 4) {
                        final Dialog dialog=new Dialog(MainActivity.this);
                        dialog.setContentView(R.layout.popup);
                        dialog.setTitle("Engine");

                        MaterialSpinner Silencer = dialog.findViewById(R.id.Silencer);
                        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Silencer.setAdapter(adapter);
                        if(silencer != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Abnormal_Engine_Noise = dialog.findViewById(R.id.Abnormal_Engine_Noise);
                        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Abnormal_Engine_Noise.setAdapter(adapter1);
                        if(engine != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Plugs = dialog.findViewById(R.id.Plugs);
                        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Plugs.setAdapter(adapter2);
                        if(plugs != "" ) {
                            int pos = adapter.getPosition(plugs);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil = dialog.findViewById(R.id.Oil);
                        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil.setAdapter(adapter3);
                        if(oil != "" ) {
                            int pos = adapter.getPosition(oil);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Radiator_Condenser = dialog.findViewById(R.id.Radiator_Condenser);
                        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Radiator_Condenser.setAdapter(adapter4);
                        if(radiator_condenser != "" ) {
                            int pos = adapter.getPosition(radiator_condenser);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil_Leakage = dialog.findViewById(R.id.Oil_Leakage);
                        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil_Leakage.setAdapter(adapter5);
                        if(oil_leakage != "" ) {
                            int pos = adapter.getPosition(oil_leakage);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Fan_Belts = dialog.findViewById(R.id.Fan_Belts);
                        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Fan_Belts.setAdapter(adapter6);
                        if(fan_belts != "" ) {
                            int pos = adapter.getPosition(fan_belts);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Filters = dialog.findViewById(R.id.Filters);
                        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Filters.setAdapter(adapter7);
                        if(filters != "" ) {
                            int pos = adapter.getPosition(filters);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Suspension_Noise_WhileDriving_Front_Rear = dialog.findViewById(R.id.Suspension_Noise_WhileDriving_Front_Rear);
                        ArrayAdapter<CharSequence> adapter8 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Suspension_Noise_WhileDriving_Front_Rear.setAdapter(adapter8);
                        if(suspension_noise_whileDriving_front_rear != "" ) {
                            int pos = adapter.getPosition(suspension_noise_whileDriving_front_rear);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Lock = dialog.findViewById(R.id.Steering_Lock);
                        ArrayAdapter<CharSequence> adapter9 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Lock.setAdapter(adapter9);
                        if(steering_lock != "" ) {
                            int pos = adapter.getPosition(steering_lock);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Wheel_Alignment_Balancing_Wobbling = dialog.findViewById(R.id.Wheel_Alignment_Balancing_Wobbling);
                        ArrayAdapter<CharSequence> adapter10 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Wheel_Alignment_Balancing_Wobbling.setAdapter(adapter10);
                        if(wheel_alignment_balancing_wobbling != "" ) {
                            int pos = adapter.getPosition(wheel_alignment_balancing_wobbling);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Operation = dialog.findViewById(R.id.Steering_Operation);
                        ArrayAdapter<CharSequence> adapter11 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Operation.setAdapter(adapter11);
                        if(steering_operation != "" ) {
                            int pos = adapter.getPosition(steering_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Pedal_Operation = dialog.findViewById(R.id.Pedal_Operation);
                        ArrayAdapter<CharSequence> adapter12 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Pedal_Operation.setAdapter(adapter12);
                        if(pedal_operation != "" ) {
                            int pos = adapter.getPosition(pedal_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Brakes_and_Hand_Brake = dialog.findViewById(R.id.Brakes_and_Hand_Brake);
                        ArrayAdapter<CharSequence> adapter13 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Brakes_and_Hand_Brake.setAdapter(adapter13);
                        if(brakes_and_hand_brake != "" ) {
                            int pos = adapter.getPosition(brakes_and_hand_brake);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Gear_Engagement = dialog.findViewById(R.id.Gear_Engagement);
                        ArrayAdapter<CharSequence> adapter14 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Gear_Engagement.setAdapter(adapter14);
                        if(gear_engagement != "" ) {
                            int pos = adapter.getPosition(gear_engagement);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Differential_And_Crown_RearWheel_Drive = dialog.findViewById(R.id.Differential_And_Crown_RearWheel_Drive);
                        ArrayAdapter<CharSequence> adapter15 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Differential_And_Crown_RearWheel_Drive.setAdapter(adapter15);
                        if(differential_and_crown_rearWheel_drive != "" ) {
                            int pos = adapter.getPosition(differential_and_crown_rearWheel_drive);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Instrument_Cluster_WarningLights_Gauges = dialog.findViewById(R.id.Instrument_Cluster_WarningLights_Gauges);
                        ArrayAdapter<CharSequence> adapter16 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Instrument_Cluster_WarningLights_Gauges.setAdapter(adapter16);
                        if(instrument_cluster_warningLights_gauges != "" ) {
                            int pos = adapter.getPosition(instrument_cluster_warningLights_gauges);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Alternator = dialog.findViewById(R.id.Alternator);
                        ArrayAdapter<CharSequence> adapter17 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Alternator.setAdapter(adapter17);
                        if(alternator != "" ) {
                            int pos = adapter.getPosition(alternator);
                            pos++;
                            Silencer.setSelection(pos);
                        }


                        Abnormal_Engine_Noise.setOnItemSelectedListener(MainActivity.this);
                        Plugs.setOnItemSelectedListener(MainActivity.this);
                        Oil.setOnItemSelectedListener(MainActivity.this);
                        Radiator_Condenser.setOnItemSelectedListener(MainActivity.this);
                        Oil_Leakage.setOnItemSelectedListener(MainActivity.this);
                        Fan_Belts.setOnItemSelectedListener(MainActivity.this);
                        Filters.setOnItemSelectedListener(MainActivity.this);
                        Suspension_Noise_WhileDriving_Front_Rear.setOnItemSelectedListener(MainActivity.this);
                        Steering_Lock.setOnItemSelectedListener(MainActivity.this);
                        Wheel_Alignment_Balancing_Wobbling.setOnItemSelectedListener(MainActivity.this);
                        Steering_Operation.setOnItemSelectedListener(MainActivity.this);
                        Pedal_Operation.setOnItemSelectedListener(MainActivity.this);
                        Brakes_and_Hand_Brake.setOnItemSelectedListener(MainActivity.this);
                        Gear_Engagement.setOnItemSelectedListener(MainActivity.this);
                        Differential_And_Crown_RearWheel_Drive.setOnItemSelectedListener(MainActivity.this);
                        Alternator.setOnItemSelectedListener(MainActivity.this);



                        Button save;
                        save=dialog.findViewById(R.id.save);
                        save.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(MainActivity.this, g+"Saved", Toast.LENGTH_SHORT).show();
                                ArrayList<String> array=new ArrayList<>();

                                array.add(silencer);
                                array.add(engine);

                                Intent s=new Intent(MainActivity.this,Main2Activity.class);
                                s.putExtra("1",array);
                                startActivity(s);


                            }


                        });
                        dialog.show();
                    }
                    else if (ii==5){
                        final Dialog dialog=new Dialog(MainActivity.this);
                        dialog.setContentView(R.layout.popup);
                        dialog.setTitle("Engine");

                        MaterialSpinner Silencer = dialog.findViewById(R.id.Silencer);
                        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Silencer.setAdapter(adapter);
                        if(silencer != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Abnormal_Engine_Noise = dialog.findViewById(R.id.Abnormal_Engine_Noise);
                        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Abnormal_Engine_Noise.setAdapter(adapter1);
                        if(engine != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Plugs = dialog.findViewById(R.id.Plugs);
                        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Plugs.setAdapter(adapter2);
                        if(plugs != "" ) {
                            int pos = adapter.getPosition(plugs);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil = dialog.findViewById(R.id.Oil);
                        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil.setAdapter(adapter3);
                        if(oil != "" ) {
                            int pos = adapter.getPosition(oil);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Radiator_Condenser = dialog.findViewById(R.id.Radiator_Condenser);
                        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Radiator_Condenser.setAdapter(adapter4);
                        if(radiator_condenser != "" ) {
                            int pos = adapter.getPosition(radiator_condenser);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil_Leakage = dialog.findViewById(R.id.Oil_Leakage);
                        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil_Leakage.setAdapter(adapter5);
                        if(oil_leakage != "" ) {
                            int pos = adapter.getPosition(oil_leakage);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Fan_Belts = dialog.findViewById(R.id.Fan_Belts);
                        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Fan_Belts.setAdapter(adapter6);
                        if(fan_belts != "" ) {
                            int pos = adapter.getPosition(fan_belts);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Filters = dialog.findViewById(R.id.Filters);
                        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Filters.setAdapter(adapter7);
                        if(filters != "" ) {
                            int pos = adapter.getPosition(filters);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Suspension_Noise_WhileDriving_Front_Rear = dialog.findViewById(R.id.Suspension_Noise_WhileDriving_Front_Rear);
                        ArrayAdapter<CharSequence> adapter8 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Suspension_Noise_WhileDriving_Front_Rear.setAdapter(adapter8);
                        if(suspension_noise_whileDriving_front_rear != "" ) {
                            int pos = adapter.getPosition(suspension_noise_whileDriving_front_rear);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Lock = dialog.findViewById(R.id.Steering_Lock);
                        ArrayAdapter<CharSequence> adapter9 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Lock.setAdapter(adapter9);
                        if(steering_lock != "" ) {
                            int pos = adapter.getPosition(steering_lock);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Wheel_Alignment_Balancing_Wobbling = dialog.findViewById(R.id.Wheel_Alignment_Balancing_Wobbling);
                        ArrayAdapter<CharSequence> adapter10 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Wheel_Alignment_Balancing_Wobbling.setAdapter(adapter10);
                        if(wheel_alignment_balancing_wobbling != "" ) {
                            int pos = adapter.getPosition(wheel_alignment_balancing_wobbling);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Operation = dialog.findViewById(R.id.Steering_Operation);
                        ArrayAdapter<CharSequence> adapter11 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Operation.setAdapter(adapter11);
                        if(steering_operation != "" ) {
                            int pos = adapter.getPosition(steering_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Pedal_Operation = dialog.findViewById(R.id.Pedal_Operation);
                        ArrayAdapter<CharSequence> adapter12 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Pedal_Operation.setAdapter(adapter12);
                        if(pedal_operation != "" ) {
                            int pos = adapter.getPosition(pedal_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Brakes_and_Hand_Brake = dialog.findViewById(R.id.Brakes_and_Hand_Brake);
                        ArrayAdapter<CharSequence> adapter13 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Brakes_and_Hand_Brake.setAdapter(adapter13);
                        if(brakes_and_hand_brake != "" ) {
                            int pos = adapter.getPosition(brakes_and_hand_brake);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Gear_Engagement = dialog.findViewById(R.id.Gear_Engagement);
                        ArrayAdapter<CharSequence> adapter14 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Gear_Engagement.setAdapter(adapter14);
                        if(gear_engagement != "" ) {
                            int pos = adapter.getPosition(gear_engagement);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Differential_And_Crown_RearWheel_Drive = dialog.findViewById(R.id.Differential_And_Crown_RearWheel_Drive);
                        ArrayAdapter<CharSequence> adapter15 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Differential_And_Crown_RearWheel_Drive.setAdapter(adapter15);
                        if(differential_and_crown_rearWheel_drive != "" ) {
                            int pos = adapter.getPosition(differential_and_crown_rearWheel_drive);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Instrument_Cluster_WarningLights_Gauges = dialog.findViewById(R.id.Instrument_Cluster_WarningLights_Gauges);
                        ArrayAdapter<CharSequence> adapter16 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Instrument_Cluster_WarningLights_Gauges.setAdapter(adapter16);
                        if(instrument_cluster_warningLights_gauges != "" ) {
                            int pos = adapter.getPosition(instrument_cluster_warningLights_gauges);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Alternator = dialog.findViewById(R.id.Alternator);
                        ArrayAdapter<CharSequence> adapter17 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Alternator.setAdapter(adapter17);
                        if(alternator != "" ) {
                            int pos = adapter.getPosition(alternator);
                            pos++;
                            Silencer.setSelection(pos);
                        }


                        Abnormal_Engine_Noise.setOnItemSelectedListener(MainActivity.this);
                        Plugs.setOnItemSelectedListener(MainActivity.this);
                        Oil.setOnItemSelectedListener(MainActivity.this);
                        Radiator_Condenser.setOnItemSelectedListener(MainActivity.this);
                        Oil_Leakage.setOnItemSelectedListener(MainActivity.this);
                        Fan_Belts.setOnItemSelectedListener(MainActivity.this);
                        Filters.setOnItemSelectedListener(MainActivity.this);
                        Suspension_Noise_WhileDriving_Front_Rear.setOnItemSelectedListener(MainActivity.this);
                        Steering_Lock.setOnItemSelectedListener(MainActivity.this);
                        Wheel_Alignment_Balancing_Wobbling.setOnItemSelectedListener(MainActivity.this);
                        Steering_Operation.setOnItemSelectedListener(MainActivity.this);
                        Pedal_Operation.setOnItemSelectedListener(MainActivity.this);
                        Brakes_and_Hand_Brake.setOnItemSelectedListener(MainActivity.this);
                        Gear_Engagement.setOnItemSelectedListener(MainActivity.this);
                        Differential_And_Crown_RearWheel_Drive.setOnItemSelectedListener(MainActivity.this);
                        Alternator.setOnItemSelectedListener(MainActivity.this);



                        Button save;
                        save=dialog.findViewById(R.id.save);
                        save.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(MainActivity.this, g+"Saved", Toast.LENGTH_SHORT).show();
                                ArrayList<String> array=new ArrayList<>();

                                array.add(silencer);
                                array.add(engine);

                                Intent s=new Intent(MainActivity.this,Main2Activity.class);
                                s.putExtra("1",array);
                                startActivity(s);


                            }


                        });
                        dialog.show();
                    }
                    else if (ii==6){
                        final Dialog dialog=new Dialog(MainActivity.this);
                        dialog.setContentView(R.layout.popup);
                        dialog.setTitle("Engine");

                        MaterialSpinner Silencer = dialog.findViewById(R.id.Silencer);
                        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Silencer.setAdapter(adapter);
                        if(silencer != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Abnormal_Engine_Noise = dialog.findViewById(R.id.Abnormal_Engine_Noise);
                        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Abnormal_Engine_Noise.setAdapter(adapter1);
                        if(engine != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Plugs = dialog.findViewById(R.id.Plugs);
                        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Plugs.setAdapter(adapter2);
                        if(plugs != "" ) {
                            int pos = adapter.getPosition(plugs);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil = dialog.findViewById(R.id.Oil);
                        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil.setAdapter(adapter3);
                        if(oil != "" ) {
                            int pos = adapter.getPosition(oil);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Radiator_Condenser = dialog.findViewById(R.id.Radiator_Condenser);
                        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Radiator_Condenser.setAdapter(adapter4);
                        if(radiator_condenser != "" ) {
                            int pos = adapter.getPosition(radiator_condenser);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil_Leakage = dialog.findViewById(R.id.Oil_Leakage);
                        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil_Leakage.setAdapter(adapter5);
                        if(oil_leakage != "" ) {
                            int pos = adapter.getPosition(oil_leakage);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Fan_Belts = dialog.findViewById(R.id.Fan_Belts);
                        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Fan_Belts.setAdapter(adapter6);
                        if(fan_belts != "" ) {
                            int pos = adapter.getPosition(fan_belts);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Filters = dialog.findViewById(R.id.Filters);
                        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Filters.setAdapter(adapter7);
                        if(filters != "" ) {
                            int pos = adapter.getPosition(filters);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Suspension_Noise_WhileDriving_Front_Rear = dialog.findViewById(R.id.Suspension_Noise_WhileDriving_Front_Rear);
                        ArrayAdapter<CharSequence> adapter8 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Suspension_Noise_WhileDriving_Front_Rear.setAdapter(adapter8);
                        if(suspension_noise_whileDriving_front_rear != "" ) {
                            int pos = adapter.getPosition(suspension_noise_whileDriving_front_rear);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Lock = dialog.findViewById(R.id.Steering_Lock);
                        ArrayAdapter<CharSequence> adapter9 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Lock.setAdapter(adapter9);
                        if(steering_lock != "" ) {
                            int pos = adapter.getPosition(steering_lock);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Wheel_Alignment_Balancing_Wobbling = dialog.findViewById(R.id.Wheel_Alignment_Balancing_Wobbling);
                        ArrayAdapter<CharSequence> adapter10 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Wheel_Alignment_Balancing_Wobbling.setAdapter(adapter10);
                        if(wheel_alignment_balancing_wobbling != "" ) {
                            int pos = adapter.getPosition(wheel_alignment_balancing_wobbling);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Operation = dialog.findViewById(R.id.Steering_Operation);
                        ArrayAdapter<CharSequence> adapter11 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Operation.setAdapter(adapter11);
                        if(steering_operation != "" ) {
                            int pos = adapter.getPosition(steering_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Pedal_Operation = dialog.findViewById(R.id.Pedal_Operation);
                        ArrayAdapter<CharSequence> adapter12 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Pedal_Operation.setAdapter(adapter12);
                        if(pedal_operation != "" ) {
                            int pos = adapter.getPosition(pedal_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Brakes_and_Hand_Brake = dialog.findViewById(R.id.Brakes_and_Hand_Brake);
                        ArrayAdapter<CharSequence> adapter13 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Brakes_and_Hand_Brake.setAdapter(adapter13);
                        if(brakes_and_hand_brake != "" ) {
                            int pos = adapter.getPosition(brakes_and_hand_brake);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Gear_Engagement = dialog.findViewById(R.id.Gear_Engagement);
                        ArrayAdapter<CharSequence> adapter14 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Gear_Engagement.setAdapter(adapter14);
                        if(gear_engagement != "" ) {
                            int pos = adapter.getPosition(gear_engagement);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Differential_And_Crown_RearWheel_Drive = dialog.findViewById(R.id.Differential_And_Crown_RearWheel_Drive);
                        ArrayAdapter<CharSequence> adapter15 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Differential_And_Crown_RearWheel_Drive.setAdapter(adapter15);
                        if(differential_and_crown_rearWheel_drive != "" ) {
                            int pos = adapter.getPosition(differential_and_crown_rearWheel_drive);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Instrument_Cluster_WarningLights_Gauges = dialog.findViewById(R.id.Instrument_Cluster_WarningLights_Gauges);
                        ArrayAdapter<CharSequence> adapter16 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Instrument_Cluster_WarningLights_Gauges.setAdapter(adapter16);
                        if(instrument_cluster_warningLights_gauges != "" ) {
                            int pos = adapter.getPosition(instrument_cluster_warningLights_gauges);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Alternator = dialog.findViewById(R.id.Alternator);
                        ArrayAdapter<CharSequence> adapter17 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Alternator.setAdapter(adapter17);
                        if(alternator != "" ) {
                            int pos = adapter.getPosition(alternator);
                            pos++;
                            Silencer.setSelection(pos);
                        }


                        Abnormal_Engine_Noise.setOnItemSelectedListener(MainActivity.this);
                        Plugs.setOnItemSelectedListener(MainActivity.this);
                        Oil.setOnItemSelectedListener(MainActivity.this);
                        Radiator_Condenser.setOnItemSelectedListener(MainActivity.this);
                        Oil_Leakage.setOnItemSelectedListener(MainActivity.this);
                        Fan_Belts.setOnItemSelectedListener(MainActivity.this);
                        Filters.setOnItemSelectedListener(MainActivity.this);
                        Suspension_Noise_WhileDriving_Front_Rear.setOnItemSelectedListener(MainActivity.this);
                        Steering_Lock.setOnItemSelectedListener(MainActivity.this);
                        Wheel_Alignment_Balancing_Wobbling.setOnItemSelectedListener(MainActivity.this);
                        Steering_Operation.setOnItemSelectedListener(MainActivity.this);
                        Pedal_Operation.setOnItemSelectedListener(MainActivity.this);
                        Brakes_and_Hand_Brake.setOnItemSelectedListener(MainActivity.this);
                        Gear_Engagement.setOnItemSelectedListener(MainActivity.this);
                        Differential_And_Crown_RearWheel_Drive.setOnItemSelectedListener(MainActivity.this);
                        Alternator.setOnItemSelectedListener(MainActivity.this);



                        Button save;
                        save=dialog.findViewById(R.id.save);
                        save.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(MainActivity.this, g+"Saved", Toast.LENGTH_SHORT).show();
                                ArrayList<String> array=new ArrayList<>();

                                array.add(silencer);
                                array.add(engine);

                                Intent s=new Intent(MainActivity.this,Main2Activity.class);
                                s.putExtra("1",array);
                                startActivity(s);


                            }


                        });
                        dialog.show();
                    }
                    else if (ii==7){
                        final Dialog dialog=new Dialog(MainActivity.this);
                        dialog.setContentView(R.layout.popup);
                        dialog.setTitle("Engine");

                        MaterialSpinner Silencer = dialog.findViewById(R.id.Silencer);
                        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Silencer.setAdapter(adapter);
                        if(silencer != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Abnormal_Engine_Noise = dialog.findViewById(R.id.Abnormal_Engine_Noise);
                        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Abnormal_Engine_Noise.setAdapter(adapter1);
                        if(engine != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Plugs = dialog.findViewById(R.id.Plugs);
                        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Plugs.setAdapter(adapter2);
                        if(plugs != "" ) {
                            int pos = adapter.getPosition(plugs);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil = dialog.findViewById(R.id.Oil);
                        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil.setAdapter(adapter3);
                        if(oil != "" ) {
                            int pos = adapter.getPosition(oil);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Radiator_Condenser = dialog.findViewById(R.id.Radiator_Condenser);
                        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Radiator_Condenser.setAdapter(adapter4);
                        if(radiator_condenser != "" ) {
                            int pos = adapter.getPosition(radiator_condenser);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil_Leakage = dialog.findViewById(R.id.Oil_Leakage);
                        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil_Leakage.setAdapter(adapter5);
                        if(oil_leakage != "" ) {
                            int pos = adapter.getPosition(oil_leakage);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Fan_Belts = dialog.findViewById(R.id.Fan_Belts);
                        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Fan_Belts.setAdapter(adapter6);
                        if(fan_belts != "" ) {
                            int pos = adapter.getPosition(fan_belts);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Filters = dialog.findViewById(R.id.Filters);
                        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Filters.setAdapter(adapter7);
                        if(filters != "" ) {
                            int pos = adapter.getPosition(filters);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Suspension_Noise_WhileDriving_Front_Rear = dialog.findViewById(R.id.Suspension_Noise_WhileDriving_Front_Rear);
                        ArrayAdapter<CharSequence> adapter8 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Suspension_Noise_WhileDriving_Front_Rear.setAdapter(adapter8);
                        if(suspension_noise_whileDriving_front_rear != "" ) {
                            int pos = adapter.getPosition(suspension_noise_whileDriving_front_rear);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Lock = dialog.findViewById(R.id.Steering_Lock);
                        ArrayAdapter<CharSequence> adapter9 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Lock.setAdapter(adapter9);
                        if(steering_lock != "" ) {
                            int pos = adapter.getPosition(steering_lock);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Wheel_Alignment_Balancing_Wobbling = dialog.findViewById(R.id.Wheel_Alignment_Balancing_Wobbling);
                        ArrayAdapter<CharSequence> adapter10 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Wheel_Alignment_Balancing_Wobbling.setAdapter(adapter10);
                        if(wheel_alignment_balancing_wobbling != "" ) {
                            int pos = adapter.getPosition(wheel_alignment_balancing_wobbling);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Operation = dialog.findViewById(R.id.Steering_Operation);
                        ArrayAdapter<CharSequence> adapter11 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Operation.setAdapter(adapter11);
                        if(steering_operation != "" ) {
                            int pos = adapter.getPosition(steering_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Pedal_Operation = dialog.findViewById(R.id.Pedal_Operation);
                        ArrayAdapter<CharSequence> adapter12 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Pedal_Operation.setAdapter(adapter12);
                        if(pedal_operation != "" ) {
                            int pos = adapter.getPosition(pedal_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Brakes_and_Hand_Brake = dialog.findViewById(R.id.Brakes_and_Hand_Brake);
                        ArrayAdapter<CharSequence> adapter13 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Brakes_and_Hand_Brake.setAdapter(adapter13);
                        if(brakes_and_hand_brake != "" ) {
                            int pos = adapter.getPosition(brakes_and_hand_brake);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Gear_Engagement = dialog.findViewById(R.id.Gear_Engagement);
                        ArrayAdapter<CharSequence> adapter14 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Gear_Engagement.setAdapter(adapter14);
                        if(gear_engagement != "" ) {
                            int pos = adapter.getPosition(gear_engagement);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Differential_And_Crown_RearWheel_Drive = dialog.findViewById(R.id.Differential_And_Crown_RearWheel_Drive);
                        ArrayAdapter<CharSequence> adapter15 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Differential_And_Crown_RearWheel_Drive.setAdapter(adapter15);
                        if(differential_and_crown_rearWheel_drive != "" ) {
                            int pos = adapter.getPosition(differential_and_crown_rearWheel_drive);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Instrument_Cluster_WarningLights_Gauges = dialog.findViewById(R.id.Instrument_Cluster_WarningLights_Gauges);
                        ArrayAdapter<CharSequence> adapter16 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Instrument_Cluster_WarningLights_Gauges.setAdapter(adapter16);
                        if(instrument_cluster_warningLights_gauges != "" ) {
                            int pos = adapter.getPosition(instrument_cluster_warningLights_gauges);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Alternator = dialog.findViewById(R.id.Alternator);
                        ArrayAdapter<CharSequence> adapter17 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Alternator.setAdapter(adapter17);
                        if(alternator != "" ) {
                            int pos = adapter.getPosition(alternator);
                            pos++;
                            Silencer.setSelection(pos);
                        }


                        Abnormal_Engine_Noise.setOnItemSelectedListener(MainActivity.this);
                        Plugs.setOnItemSelectedListener(MainActivity.this);
                        Oil.setOnItemSelectedListener(MainActivity.this);
                        Radiator_Condenser.setOnItemSelectedListener(MainActivity.this);
                        Oil_Leakage.setOnItemSelectedListener(MainActivity.this);
                        Fan_Belts.setOnItemSelectedListener(MainActivity.this);
                        Filters.setOnItemSelectedListener(MainActivity.this);
                        Suspension_Noise_WhileDriving_Front_Rear.setOnItemSelectedListener(MainActivity.this);
                        Steering_Lock.setOnItemSelectedListener(MainActivity.this);
                        Wheel_Alignment_Balancing_Wobbling.setOnItemSelectedListener(MainActivity.this);
                        Steering_Operation.setOnItemSelectedListener(MainActivity.this);
                        Pedal_Operation.setOnItemSelectedListener(MainActivity.this);
                        Brakes_and_Hand_Brake.setOnItemSelectedListener(MainActivity.this);
                        Gear_Engagement.setOnItemSelectedListener(MainActivity.this);
                        Differential_And_Crown_RearWheel_Drive.setOnItemSelectedListener(MainActivity.this);
                        Alternator.setOnItemSelectedListener(MainActivity.this);



                        Button save;
                        save=dialog.findViewById(R.id.save);
                        save.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(MainActivity.this, g+"Saved", Toast.LENGTH_SHORT).show();
                                ArrayList<String> array=new ArrayList<>();

                                array.add(silencer);
                                array.add(engine);

                                Intent s=new Intent(MainActivity.this,Main2Activity.class);
                                s.putExtra("1",array);
                                startActivity(s);


                            }


                        });
                        dialog.show();
                    }
                    else if (ii==8){
                        final Dialog dialog=new Dialog(MainActivity.this);
                        dialog.setContentView(R.layout.popup);
                        dialog.setTitle("Engine");

                        MaterialSpinner Silencer = dialog.findViewById(R.id.Silencer);
                        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Silencer.setAdapter(adapter);
                        if(silencer != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Abnormal_Engine_Noise = dialog.findViewById(R.id.Abnormal_Engine_Noise);
                        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Abnormal_Engine_Noise.setAdapter(adapter1);
                        if(engine != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Plugs = dialog.findViewById(R.id.Plugs);
                        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Plugs.setAdapter(adapter2);
                        if(plugs != "" ) {
                            int pos = adapter.getPosition(plugs);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil = dialog.findViewById(R.id.Oil);
                        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil.setAdapter(adapter3);
                        if(oil != "" ) {
                            int pos = adapter.getPosition(oil);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Radiator_Condenser = dialog.findViewById(R.id.Radiator_Condenser);
                        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Radiator_Condenser.setAdapter(adapter4);
                        if(radiator_condenser != "" ) {
                            int pos = adapter.getPosition(radiator_condenser);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil_Leakage = dialog.findViewById(R.id.Oil_Leakage);
                        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil_Leakage.setAdapter(adapter5);
                        if(oil_leakage != "" ) {
                            int pos = adapter.getPosition(oil_leakage);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Fan_Belts = dialog.findViewById(R.id.Fan_Belts);
                        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Fan_Belts.setAdapter(adapter6);
                        if(fan_belts != "" ) {
                            int pos = adapter.getPosition(fan_belts);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Filters = dialog.findViewById(R.id.Filters);
                        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Filters.setAdapter(adapter7);
                        if(filters != "" ) {
                            int pos = adapter.getPosition(filters);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Suspension_Noise_WhileDriving_Front_Rear = dialog.findViewById(R.id.Suspension_Noise_WhileDriving_Front_Rear);
                        ArrayAdapter<CharSequence> adapter8 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Suspension_Noise_WhileDriving_Front_Rear.setAdapter(adapter8);
                        if(suspension_noise_whileDriving_front_rear != "" ) {
                            int pos = adapter.getPosition(suspension_noise_whileDriving_front_rear);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Lock = dialog.findViewById(R.id.Steering_Lock);
                        ArrayAdapter<CharSequence> adapter9 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Lock.setAdapter(adapter9);
                        if(steering_lock != "" ) {
                            int pos = adapter.getPosition(steering_lock);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Wheel_Alignment_Balancing_Wobbling = dialog.findViewById(R.id.Wheel_Alignment_Balancing_Wobbling);
                        ArrayAdapter<CharSequence> adapter10 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Wheel_Alignment_Balancing_Wobbling.setAdapter(adapter10);
                        if(wheel_alignment_balancing_wobbling != "" ) {
                            int pos = adapter.getPosition(wheel_alignment_balancing_wobbling);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Operation = dialog.findViewById(R.id.Steering_Operation);
                        ArrayAdapter<CharSequence> adapter11 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Operation.setAdapter(adapter11);
                        if(steering_operation != "" ) {
                            int pos = adapter.getPosition(steering_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Pedal_Operation = dialog.findViewById(R.id.Pedal_Operation);
                        ArrayAdapter<CharSequence> adapter12 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Pedal_Operation.setAdapter(adapter12);
                        if(pedal_operation != "" ) {
                            int pos = adapter.getPosition(pedal_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Brakes_and_Hand_Brake = dialog.findViewById(R.id.Brakes_and_Hand_Brake);
                        ArrayAdapter<CharSequence> adapter13 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Brakes_and_Hand_Brake.setAdapter(adapter13);
                        if(brakes_and_hand_brake != "" ) {
                            int pos = adapter.getPosition(brakes_and_hand_brake);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Gear_Engagement = dialog.findViewById(R.id.Gear_Engagement);
                        ArrayAdapter<CharSequence> adapter14 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Gear_Engagement.setAdapter(adapter14);
                        if(gear_engagement != "" ) {
                            int pos = adapter.getPosition(gear_engagement);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Differential_And_Crown_RearWheel_Drive = dialog.findViewById(R.id.Differential_And_Crown_RearWheel_Drive);
                        ArrayAdapter<CharSequence> adapter15 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Differential_And_Crown_RearWheel_Drive.setAdapter(adapter15);
                        if(differential_and_crown_rearWheel_drive != "" ) {
                            int pos = adapter.getPosition(differential_and_crown_rearWheel_drive);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Instrument_Cluster_WarningLights_Gauges = dialog.findViewById(R.id.Instrument_Cluster_WarningLights_Gauges);
                        ArrayAdapter<CharSequence> adapter16 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Instrument_Cluster_WarningLights_Gauges.setAdapter(adapter16);
                        if(instrument_cluster_warningLights_gauges != "" ) {
                            int pos = adapter.getPosition(instrument_cluster_warningLights_gauges);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Alternator = dialog.findViewById(R.id.Alternator);
                        ArrayAdapter<CharSequence> adapter17 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Alternator.setAdapter(adapter17);
                        if(alternator != "" ) {
                            int pos = adapter.getPosition(alternator);
                            pos++;
                            Silencer.setSelection(pos);
                        }


                        Abnormal_Engine_Noise.setOnItemSelectedListener(MainActivity.this);
                        Plugs.setOnItemSelectedListener(MainActivity.this);
                        Oil.setOnItemSelectedListener(MainActivity.this);
                        Radiator_Condenser.setOnItemSelectedListener(MainActivity.this);
                        Oil_Leakage.setOnItemSelectedListener(MainActivity.this);
                        Fan_Belts.setOnItemSelectedListener(MainActivity.this);
                        Filters.setOnItemSelectedListener(MainActivity.this);
                        Suspension_Noise_WhileDriving_Front_Rear.setOnItemSelectedListener(MainActivity.this);
                        Steering_Lock.setOnItemSelectedListener(MainActivity.this);
                        Wheel_Alignment_Balancing_Wobbling.setOnItemSelectedListener(MainActivity.this);
                        Steering_Operation.setOnItemSelectedListener(MainActivity.this);
                        Pedal_Operation.setOnItemSelectedListener(MainActivity.this);
                        Brakes_and_Hand_Brake.setOnItemSelectedListener(MainActivity.this);
                        Gear_Engagement.setOnItemSelectedListener(MainActivity.this);
                        Differential_And_Crown_RearWheel_Drive.setOnItemSelectedListener(MainActivity.this);
                        Alternator.setOnItemSelectedListener(MainActivity.this);



                        Button save;
                        save=dialog.findViewById(R.id.save);
                        save.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(MainActivity.this, g+"Saved", Toast.LENGTH_SHORT).show();
                                ArrayList<String> array=new ArrayList<>();

                                array.add(silencer);
                                array.add(engine);

                                Intent s=new Intent(MainActivity.this,Main2Activity.class);
                                s.putExtra("1",array);
                                startActivity(s);


                            }


                        });
                        dialog.show();
                    }
                    else if (ii==9){
                        final Dialog dialog=new Dialog(MainActivity.this);
                        dialog.setContentView(R.layout.popup);
                        dialog.setTitle("Engine");

                        MaterialSpinner Silencer = dialog.findViewById(R.id.Silencer);
                        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Silencer.setAdapter(adapter);
                        if(silencer != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Abnormal_Engine_Noise = dialog.findViewById(R.id.Abnormal_Engine_Noise);
                        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Abnormal_Engine_Noise.setAdapter(adapter1);
                        if(engine != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Plugs = dialog.findViewById(R.id.Plugs);
                        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Plugs.setAdapter(adapter2);
                        if(plugs != "" ) {
                            int pos = adapter.getPosition(plugs);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil = dialog.findViewById(R.id.Oil);
                        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil.setAdapter(adapter3);
                        if(oil != "" ) {
                            int pos = adapter.getPosition(oil);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Radiator_Condenser = dialog.findViewById(R.id.Radiator_Condenser);
                        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Radiator_Condenser.setAdapter(adapter4);
                        if(radiator_condenser != "" ) {
                            int pos = adapter.getPosition(radiator_condenser);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil_Leakage = dialog.findViewById(R.id.Oil_Leakage);
                        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil_Leakage.setAdapter(adapter5);
                        if(oil_leakage != "" ) {
                            int pos = adapter.getPosition(oil_leakage);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Fan_Belts = dialog.findViewById(R.id.Fan_Belts);
                        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Fan_Belts.setAdapter(adapter6);
                        if(fan_belts != "" ) {
                            int pos = adapter.getPosition(fan_belts);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Filters = dialog.findViewById(R.id.Filters);
                        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Filters.setAdapter(adapter7);
                        if(filters != "" ) {
                            int pos = adapter.getPosition(filters);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Suspension_Noise_WhileDriving_Front_Rear = dialog.findViewById(R.id.Suspension_Noise_WhileDriving_Front_Rear);
                        ArrayAdapter<CharSequence> adapter8 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Suspension_Noise_WhileDriving_Front_Rear.setAdapter(adapter8);
                        if(suspension_noise_whileDriving_front_rear != "" ) {
                            int pos = adapter.getPosition(suspension_noise_whileDriving_front_rear);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Lock = dialog.findViewById(R.id.Steering_Lock);
                        ArrayAdapter<CharSequence> adapter9 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Lock.setAdapter(adapter9);
                        if(steering_lock != "" ) {
                            int pos = adapter.getPosition(steering_lock);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Wheel_Alignment_Balancing_Wobbling = dialog.findViewById(R.id.Wheel_Alignment_Balancing_Wobbling);
                        ArrayAdapter<CharSequence> adapter10 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Wheel_Alignment_Balancing_Wobbling.setAdapter(adapter10);
                        if(wheel_alignment_balancing_wobbling != "" ) {
                            int pos = adapter.getPosition(wheel_alignment_balancing_wobbling);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Operation = dialog.findViewById(R.id.Steering_Operation);
                        ArrayAdapter<CharSequence> adapter11 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Operation.setAdapter(adapter11);
                        if(steering_operation != "" ) {
                            int pos = adapter.getPosition(steering_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Pedal_Operation = dialog.findViewById(R.id.Pedal_Operation);
                        ArrayAdapter<CharSequence> adapter12 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Pedal_Operation.setAdapter(adapter12);
                        if(pedal_operation != "" ) {
                            int pos = adapter.getPosition(pedal_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Brakes_and_Hand_Brake = dialog.findViewById(R.id.Brakes_and_Hand_Brake);
                        ArrayAdapter<CharSequence> adapter13 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Brakes_and_Hand_Brake.setAdapter(adapter13);
                        if(brakes_and_hand_brake != "" ) {
                            int pos = adapter.getPosition(brakes_and_hand_brake);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Gear_Engagement = dialog.findViewById(R.id.Gear_Engagement);
                        ArrayAdapter<CharSequence> adapter14 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Gear_Engagement.setAdapter(adapter14);
                        if(gear_engagement != "" ) {
                            int pos = adapter.getPosition(gear_engagement);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Differential_And_Crown_RearWheel_Drive = dialog.findViewById(R.id.Differential_And_Crown_RearWheel_Drive);
                        ArrayAdapter<CharSequence> adapter15 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Differential_And_Crown_RearWheel_Drive.setAdapter(adapter15);
                        if(differential_and_crown_rearWheel_drive != "" ) {
                            int pos = adapter.getPosition(differential_and_crown_rearWheel_drive);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Instrument_Cluster_WarningLights_Gauges = dialog.findViewById(R.id.Instrument_Cluster_WarningLights_Gauges);
                        ArrayAdapter<CharSequence> adapter16 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Instrument_Cluster_WarningLights_Gauges.setAdapter(adapter16);
                        if(instrument_cluster_warningLights_gauges != "" ) {
                            int pos = adapter.getPosition(instrument_cluster_warningLights_gauges);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Alternator = dialog.findViewById(R.id.Alternator);
                        ArrayAdapter<CharSequence> adapter17 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Alternator.setAdapter(adapter17);
                        if(alternator != "" ) {
                            int pos = adapter.getPosition(alternator);
                            pos++;
                            Silencer.setSelection(pos);
                        }


                        Abnormal_Engine_Noise.setOnItemSelectedListener(MainActivity.this);
                        Plugs.setOnItemSelectedListener(MainActivity.this);
                        Oil.setOnItemSelectedListener(MainActivity.this);
                        Radiator_Condenser.setOnItemSelectedListener(MainActivity.this);
                        Oil_Leakage.setOnItemSelectedListener(MainActivity.this);
                        Fan_Belts.setOnItemSelectedListener(MainActivity.this);
                        Filters.setOnItemSelectedListener(MainActivity.this);
                        Suspension_Noise_WhileDriving_Front_Rear.setOnItemSelectedListener(MainActivity.this);
                        Steering_Lock.setOnItemSelectedListener(MainActivity.this);
                        Wheel_Alignment_Balancing_Wobbling.setOnItemSelectedListener(MainActivity.this);
                        Steering_Operation.setOnItemSelectedListener(MainActivity.this);
                        Pedal_Operation.setOnItemSelectedListener(MainActivity.this);
                        Brakes_and_Hand_Brake.setOnItemSelectedListener(MainActivity.this);
                        Gear_Engagement.setOnItemSelectedListener(MainActivity.this);
                        Differential_And_Crown_RearWheel_Drive.setOnItemSelectedListener(MainActivity.this);
                        Alternator.setOnItemSelectedListener(MainActivity.this);



                        Button save;
                        save=dialog.findViewById(R.id.save);
                        save.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(MainActivity.this, g+"Saved", Toast.LENGTH_SHORT).show();
                                ArrayList<String> array=new ArrayList<>();

                                array.add(silencer);
                                array.add(engine);

                                Intent s=new Intent(MainActivity.this,Main2Activity.class);
                                s.putExtra("1",array);
                                startActivity(s);


                            }


                        });
                        dialog.show();
                    }
                    else if (ii==10){
                        final Dialog dialog=new Dialog(MainActivity.this);
                        dialog.setContentView(R.layout.popup);
                        dialog.setTitle("Engine");

                        MaterialSpinner Silencer = dialog.findViewById(R.id.Silencer);
                        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Silencer.setAdapter(adapter);
                        if(silencer != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Abnormal_Engine_Noise = dialog.findViewById(R.id.Abnormal_Engine_Noise);
                        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Abnormal_Engine_Noise.setAdapter(adapter1);
                        if(engine != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Plugs = dialog.findViewById(R.id.Plugs);
                        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Plugs.setAdapter(adapter2);
                        if(plugs != "" ) {
                            int pos = adapter.getPosition(plugs);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil = dialog.findViewById(R.id.Oil);
                        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil.setAdapter(adapter3);
                        if(oil != "" ) {
                            int pos = adapter.getPosition(oil);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Radiator_Condenser = dialog.findViewById(R.id.Radiator_Condenser);
                        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Radiator_Condenser.setAdapter(adapter4);
                        if(radiator_condenser != "" ) {
                            int pos = adapter.getPosition(radiator_condenser);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil_Leakage = dialog.findViewById(R.id.Oil_Leakage);
                        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil_Leakage.setAdapter(adapter5);
                        if(oil_leakage != "" ) {
                            int pos = adapter.getPosition(oil_leakage);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Fan_Belts = dialog.findViewById(R.id.Fan_Belts);
                        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Fan_Belts.setAdapter(adapter6);
                        if(fan_belts != "" ) {
                            int pos = adapter.getPosition(fan_belts);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Filters = dialog.findViewById(R.id.Filters);
                        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Filters.setAdapter(adapter7);
                        if(filters != "" ) {
                            int pos = adapter.getPosition(filters);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Suspension_Noise_WhileDriving_Front_Rear = dialog.findViewById(R.id.Suspension_Noise_WhileDriving_Front_Rear);
                        ArrayAdapter<CharSequence> adapter8 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Suspension_Noise_WhileDriving_Front_Rear.setAdapter(adapter8);
                        if(suspension_noise_whileDriving_front_rear != "" ) {
                            int pos = adapter.getPosition(suspension_noise_whileDriving_front_rear);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Lock = dialog.findViewById(R.id.Steering_Lock);
                        ArrayAdapter<CharSequence> adapter9 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Lock.setAdapter(adapter9);
                        if(steering_lock != "" ) {
                            int pos = adapter.getPosition(steering_lock);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Wheel_Alignment_Balancing_Wobbling = dialog.findViewById(R.id.Wheel_Alignment_Balancing_Wobbling);
                        ArrayAdapter<CharSequence> adapter10 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Wheel_Alignment_Balancing_Wobbling.setAdapter(adapter10);
                        if(wheel_alignment_balancing_wobbling != "" ) {
                            int pos = adapter.getPosition(wheel_alignment_balancing_wobbling);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Operation = dialog.findViewById(R.id.Steering_Operation);
                        ArrayAdapter<CharSequence> adapter11 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Operation.setAdapter(adapter11);
                        if(steering_operation != "" ) {
                            int pos = adapter.getPosition(steering_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Pedal_Operation = dialog.findViewById(R.id.Pedal_Operation);
                        ArrayAdapter<CharSequence> adapter12 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Pedal_Operation.setAdapter(adapter12);
                        if(pedal_operation != "" ) {
                            int pos = adapter.getPosition(pedal_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Brakes_and_Hand_Brake = dialog.findViewById(R.id.Brakes_and_Hand_Brake);
                        ArrayAdapter<CharSequence> adapter13 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Brakes_and_Hand_Brake.setAdapter(adapter13);
                        if(brakes_and_hand_brake != "" ) {
                            int pos = adapter.getPosition(brakes_and_hand_brake);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Gear_Engagement = dialog.findViewById(R.id.Gear_Engagement);
                        ArrayAdapter<CharSequence> adapter14 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Gear_Engagement.setAdapter(adapter14);
                        if(gear_engagement != "" ) {
                            int pos = adapter.getPosition(gear_engagement);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Differential_And_Crown_RearWheel_Drive = dialog.findViewById(R.id.Differential_And_Crown_RearWheel_Drive);
                        ArrayAdapter<CharSequence> adapter15 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Differential_And_Crown_RearWheel_Drive.setAdapter(adapter15);
                        if(differential_and_crown_rearWheel_drive != "" ) {
                            int pos = adapter.getPosition(differential_and_crown_rearWheel_drive);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Instrument_Cluster_WarningLights_Gauges = dialog.findViewById(R.id.Instrument_Cluster_WarningLights_Gauges);
                        ArrayAdapter<CharSequence> adapter16 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Instrument_Cluster_WarningLights_Gauges.setAdapter(adapter16);
                        if(instrument_cluster_warningLights_gauges != "" ) {
                            int pos = adapter.getPosition(instrument_cluster_warningLights_gauges);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Alternator = dialog.findViewById(R.id.Alternator);
                        ArrayAdapter<CharSequence> adapter17 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Alternator.setAdapter(adapter17);
                        if(alternator != "" ) {
                            int pos = adapter.getPosition(alternator);
                            pos++;
                            Silencer.setSelection(pos);
                        }


                        Abnormal_Engine_Noise.setOnItemSelectedListener(MainActivity.this);
                        Plugs.setOnItemSelectedListener(MainActivity.this);
                        Oil.setOnItemSelectedListener(MainActivity.this);
                        Radiator_Condenser.setOnItemSelectedListener(MainActivity.this);
                        Oil_Leakage.setOnItemSelectedListener(MainActivity.this);
                        Fan_Belts.setOnItemSelectedListener(MainActivity.this);
                        Filters.setOnItemSelectedListener(MainActivity.this);
                        Suspension_Noise_WhileDriving_Front_Rear.setOnItemSelectedListener(MainActivity.this);
                        Steering_Lock.setOnItemSelectedListener(MainActivity.this);
                        Wheel_Alignment_Balancing_Wobbling.setOnItemSelectedListener(MainActivity.this);
                        Steering_Operation.setOnItemSelectedListener(MainActivity.this);
                        Pedal_Operation.setOnItemSelectedListener(MainActivity.this);
                        Brakes_and_Hand_Brake.setOnItemSelectedListener(MainActivity.this);
                        Gear_Engagement.setOnItemSelectedListener(MainActivity.this);
                        Differential_And_Crown_RearWheel_Drive.setOnItemSelectedListener(MainActivity.this);
                        Alternator.setOnItemSelectedListener(MainActivity.this);



                        Button save;
                        save=dialog.findViewById(R.id.save);
                        save.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(MainActivity.this, g+"Saved", Toast.LENGTH_SHORT).show();
                                ArrayList<String> array=new ArrayList<>();

                                array.add(silencer);
                                array.add(engine);

                                Intent s=new Intent(MainActivity.this,Main2Activity.class);
                                s.putExtra("1",array);
                                startActivity(s);


                            }


                        });
                        dialog.show();
                    }
                    else if (ii==11){
                        final Dialog dialog=new Dialog(MainActivity.this);
                        dialog.setContentView(R.layout.popup);
                        dialog.setTitle("Engine");

                        MaterialSpinner Silencer = dialog.findViewById(R.id.Silencer);
                        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Silencer.setAdapter(adapter);
                        if(silencer != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Abnormal_Engine_Noise = dialog.findViewById(R.id.Abnormal_Engine_Noise);
                        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Abnormal_Engine_Noise.setAdapter(adapter1);
                        if(engine != "" ) {
                            int pos = adapter.getPosition(silencer);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Plugs = dialog.findViewById(R.id.Plugs);
                        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Plugs.setAdapter(adapter2);
                        if(plugs != "" ) {
                            int pos = adapter.getPosition(plugs);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil = dialog.findViewById(R.id.Oil);
                        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil.setAdapter(adapter3);
                        if(oil != "" ) {
                            int pos = adapter.getPosition(oil);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Radiator_Condenser = dialog.findViewById(R.id.Radiator_Condenser);
                        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Radiator_Condenser.setAdapter(adapter4);
                        if(radiator_condenser != "" ) {
                            int pos = adapter.getPosition(radiator_condenser);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Oil_Leakage = dialog.findViewById(R.id.Oil_Leakage);
                        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Oil_Leakage.setAdapter(adapter5);
                        if(oil_leakage != "" ) {
                            int pos = adapter.getPosition(oil_leakage);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Fan_Belts = dialog.findViewById(R.id.Fan_Belts);
                        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Fan_Belts.setAdapter(adapter6);
                        if(fan_belts != "" ) {
                            int pos = adapter.getPosition(fan_belts);
                            pos++;
                            Silencer.setSelection(pos);
                        }
//
                        MaterialSpinner Filters = dialog.findViewById(R.id.Filters);
                        ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Filters.setAdapter(adapter7);
                        if(filters != "" ) {
                            int pos = adapter.getPosition(filters);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Suspension_Noise_WhileDriving_Front_Rear = dialog.findViewById(R.id.Suspension_Noise_WhileDriving_Front_Rear);
                        ArrayAdapter<CharSequence> adapter8 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Suspension_Noise_WhileDriving_Front_Rear.setAdapter(adapter8);
                        if(suspension_noise_whileDriving_front_rear != "" ) {
                            int pos = adapter.getPosition(suspension_noise_whileDriving_front_rear);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Lock = dialog.findViewById(R.id.Steering_Lock);
                        ArrayAdapter<CharSequence> adapter9 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Lock.setAdapter(adapter9);
                        if(steering_lock != "" ) {
                            int pos = adapter.getPosition(steering_lock);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Wheel_Alignment_Balancing_Wobbling = dialog.findViewById(R.id.Wheel_Alignment_Balancing_Wobbling);
                        ArrayAdapter<CharSequence> adapter10 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Wheel_Alignment_Balancing_Wobbling.setAdapter(adapter10);
                        if(wheel_alignment_balancing_wobbling != "" ) {
                            int pos = adapter.getPosition(wheel_alignment_balancing_wobbling);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Steering_Operation = dialog.findViewById(R.id.Steering_Operation);
                        ArrayAdapter<CharSequence> adapter11 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Steering_Operation.setAdapter(adapter11);
                        if(steering_operation != "" ) {
                            int pos = adapter.getPosition(steering_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Pedal_Operation = dialog.findViewById(R.id.Pedal_Operation);
                        ArrayAdapter<CharSequence> adapter12 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Pedal_Operation.setAdapter(adapter12);
                        if(pedal_operation != "" ) {
                            int pos = adapter.getPosition(pedal_operation);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Brakes_and_Hand_Brake = dialog.findViewById(R.id.Brakes_and_Hand_Brake);
                        ArrayAdapter<CharSequence> adapter13 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Brakes_and_Hand_Brake.setAdapter(adapter13);
                        if(brakes_and_hand_brake != "" ) {
                            int pos = adapter.getPosition(brakes_and_hand_brake);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Gear_Engagement = dialog.findViewById(R.id.Gear_Engagement);
                        ArrayAdapter<CharSequence> adapter14 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Gear_Engagement.setAdapter(adapter14);
                        if(gear_engagement != "" ) {
                            int pos = adapter.getPosition(gear_engagement);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Differential_And_Crown_RearWheel_Drive = dialog.findViewById(R.id.Differential_And_Crown_RearWheel_Drive);
                        ArrayAdapter<CharSequence> adapter15 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Differential_And_Crown_RearWheel_Drive.setAdapter(adapter15);
                        if(differential_and_crown_rearWheel_drive != "" ) {
                            int pos = adapter.getPosition(differential_and_crown_rearWheel_drive);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Instrument_Cluster_WarningLights_Gauges = dialog.findViewById(R.id.Instrument_Cluster_WarningLights_Gauges);
                        ArrayAdapter<CharSequence> adapter16 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Instrument_Cluster_WarningLights_Gauges.setAdapter(adapter16);
                        if(instrument_cluster_warningLights_gauges != "" ) {
                            int pos = adapter.getPosition(instrument_cluster_warningLights_gauges);
                            pos++;
                            Silencer.setSelection(pos);
                        }

                        MaterialSpinner Alternator = dialog.findViewById(R.id.Alternator);
                        ArrayAdapter<CharSequence> adapter17 = ArrayAdapter.createFromResource(MainActivity.this, R.array.values, android.R.layout.simple_spinner_item);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        Alternator.setAdapter(adapter17);
                        if(alternator != "" ) {
                            int pos = adapter.getPosition(alternator);
                            pos++;
                            Silencer.setSelection(pos);
                        }


                        Abnormal_Engine_Noise.setOnItemSelectedListener(MainActivity.this);
                        Plugs.setOnItemSelectedListener(MainActivity.this);
                        Oil.setOnItemSelectedListener(MainActivity.this);
                        Radiator_Condenser.setOnItemSelectedListener(MainActivity.this);
                        Oil_Leakage.setOnItemSelectedListener(MainActivity.this);
                        Fan_Belts.setOnItemSelectedListener(MainActivity.this);
                        Filters.setOnItemSelectedListener(MainActivity.this);
                        Suspension_Noise_WhileDriving_Front_Rear.setOnItemSelectedListener(MainActivity.this);
                        Steering_Lock.setOnItemSelectedListener(MainActivity.this);
                        Wheel_Alignment_Balancing_Wobbling.setOnItemSelectedListener(MainActivity.this);
                        Steering_Operation.setOnItemSelectedListener(MainActivity.this);
                        Pedal_Operation.setOnItemSelectedListener(MainActivity.this);
                        Brakes_and_Hand_Brake.setOnItemSelectedListener(MainActivity.this);
                        Gear_Engagement.setOnItemSelectedListener(MainActivity.this);
                        Differential_And_Crown_RearWheel_Drive.setOnItemSelectedListener(MainActivity.this);
                        Alternator.setOnItemSelectedListener(MainActivity.this);



                        Button save;
                        save=dialog.findViewById(R.id.save);
                        save.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(MainActivity.this, g+"Saved", Toast.LENGTH_SHORT).show();
                                ArrayList<String> array=new ArrayList<>();

                                array.add(silencer);
                                array.add(engine);

                                Intent s=new Intent(MainActivity.this,Main2Activity.class);
                                s.putExtra("1",array);
                                startActivity(s);


                            }


                        });
                        dialog.show();
                    }


                }
            });
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        switch (parent.getId()){
            case R.id.Silencer:
                silencer=parent.getItemAtPosition(position).toString();
                Toast.makeText(this, ""+silencer, Toast.LENGTH_SHORT).show();

            case R.id.Abnormal_Engine_Noise:
                engine=parent.getItemAtPosition(position).toString();
                Toast.makeText(this, ""+engine, Toast.LENGTH_SHORT).show();



        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
//Silencer.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//@Override
//public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//        g=parent.getItemAtPosition(position).toString();
//        }
//
//@Override
//public void onNothingSelected(AdapterView<?> parent) {
//
//        }
//        });