package com.example.gridlayout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class Main2Activity extends AppCompatActivity {
    TextView tv;
    int i;
    private  String s;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        tv=findViewById(R.id.tv);
        ArrayList<String> arr= new ArrayList<>();
        //final String silencer = getIntent().getExtras().getString("1");
        arr=getIntent().getExtras().getStringArrayList("1");

        for( i=0;i<arr.size();i++)
        {
            //Log.e("hi", arr.get(i));
             s=arr.get(i);
            tv.append(s+"\n");

        }

    }
}
